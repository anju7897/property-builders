<?= $this->extend('Modules\Frontend\Views\layouts\headerFooter'); ?>
<?= $this->section('content') ?>





        <!--Start Main Slider Four-->
        <section class="main-slider-four">
            <div class="main-slider-four__carousel owl-carousel owl-theme">
                <!--Start Main Slider Four Single-->
                <div class="main-slider-four__single">
                    <div class="main-slider-four__bg"
                        style="background-image: url(assets/img/builders-img-1.jpeg);"></div>
                    <div class="shape1 float-bob-x"><img src="assets/img/builders-img-1.jpeg" alt="">
                    </div>
                    <div class="container">
                        <div class="main-slider-four__content">
                            <div class="tagline">
                                <span>Welcome to Dubai.</span>
                            </div>
                            <div class="title-box">
                                <h2>Smart Dubai Investments, <br>Expertly Guided</h2>
                            </div>
                            <div class="text-box">
                                <p>Get personalized property options and exclusive access with transparent, expert support.</p>
                            </div>

                            <div class="main-slider-four__btn">
                                <a class="thm-btn" href="#">Contact Now!
                                    <i class="icon-next"></i>
                                    <span class="hover-btn hover-bx"></span>
                                    <span class="hover-btn hover-bx2"></span>
                                    <span class="hover-btn hover-bx3"></span>
                                    <span class="hover-btn hover-bx4"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Main Slider Four Single-->

                <!--Start Main Slider Four Single-->
                <div class="main-slider-four__single">
                    <div class="main-slider-four__bg"
                        style="background-image: url(assets/img/builders-img.jpeg);"></div>
                    <div class="shape1 float-bob-x"><img src="assets/img/builders-img.jpeg" alt="">
                    </div>
                    <div class="container">
                        <div class="main-slider-four__content">
                            <div class="tagline">
                                <span>Welcome to Dubai.</span>
                            </div>
                            <div class="title-box">
                                <h2>Your Trusted Guide to Dubai Property</h2>
                            </div>
                            <div class="text-box">
                                <p>Smart, clear, and personalized support for your Dubai property investment.</p>
                            </div>

                            <div class="main-slider-four__btn">
                                <a class="thm-btn" href="#">Contact Now
                                    <i class="icon-next"></i>
                                    <span class="hover-btn hover-bx"></span>
                                    <span class="hover-btn hover-bx2"></span>
                                    <span class="hover-btn hover-bx3"></span>
                                    <span class="hover-btn hover-bx4"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Main Slider Four Single-->

                
            </div>

            
        </section>
        <!--End Main Slider Four-->
<style>
    @media (max-width: 576px){
        .about-video {
            height: 300px !important;
            width: 100% !important;
            object-fit: cover;
        }
    }
</style>

        <!--Start About Five-->
        <section class="about-five">
            <div class="shape1 float-bob-x"><img src="assets/images/shapes/about-v5-shape1.png" alt=""></div>
            <div class="container">
                <div class="row">
                    <!--Start About Five Img-->
                    <div class="col-xl-5 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="about-five__img clearfix">
                            <div class="about-five__img1">
                                <div class="about-five__img1-inner">
								<video src="assets/img/dubai-builders.mp4" 
									controls autoplay muted loop 
									style="width:100%; height:580px; display:block; margin:0; padding:0; object-fit:cover;" class="about-video">
								</video>

                                </div>
                                <div class="experince-box">
                                    <h2>--- +Years Experince</h2>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                    <!--End About Five Img-->

                    <!--Start About Five Content-->
                    <div class="col-xl-7 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="about-five__content">
                            <div class="sec-title sec-title-animation animation-style2">
                                <div class="sec-title__tagline">
                                    <div class="icon-box">
                                        <span class="icon-household"></span>
                                    </div>

                                    <div class="text title-animation">
                                        <h4>About Us</h4>
                                    </div>
                                </div>
                                <h2 class="sec-title__title title-animation">Your Trusted Guide for Smart, Secure & High-Return Dubai Property Investments
                                </h2>
                            </div>

                            <div class="about-five__content-text1">
                                <p>I bring deep expertise in the Dubai real estate market combined with a clear understanding of how Indian investors think, plan, and make decisions. Every project I recommend is aligned with your goals, budget, and risk appetite — ensuring a completely personalized investment journey. With strong connections to Dubai’s leading developers, you gain access to exclusive launches, priority inventory, and more flexible payment plans. My process is transparent, simplified, and designed to help you invest with full confidence. Whether you want high rental income, long-term appreciation, or a premium holiday home, I guide you end-to-end with clarity, honesty, and real market expertise.</p>
                            </div>

                            <div class="about-five__content-text2">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-6 col-md-6">
                                        <div class="about-five__content-text2-single">
                                           <ul class="about-four__content-list">
                                    <li>
                                        <p><span class="icon-checkmark"></span> Deep Understanding of Dubai Real Estate</p>
                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Expert Insight Into Indian Investor Mindset</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Fully Personalized Property Recommendations</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Exclusive Access to Top Developers</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Transparent & Honest Guidance</p>
                                    </li>
                                </ul>
                                        </div>
                                    </div>


                                </div>
                            </div>

                            <div class="about-five__content-bottom">
                                <div class="btn-box">
                                    <a class="thm-btn" href="#">More About Us
                                        <i class="icon-next"></i>
                                        <span class="hover-btn hover-bx"></span>
                                        <span class="hover-btn hover-bx2"></span>
                                        <span class="hover-btn hover-bx3"></span>
                                        <span class="hover-btn hover-bx4"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About Five Content-->
                </div>
            </div>
        </section>
        <!--End About Five-->

        <!--Start Services Four-->
        <section class="services-four">
            <div class="services-four__pattern"
                style="background-image: url(assets/images/pattern/services-v4-pattern.png);"></div>
            <div class="container">
                <div class="sec-title text-center sec-title-animation animation-style1">
                    <div class="sec-title__tagline center">
                        <div class="icon-box">
                            <span class="icon-household"></span>
                        </div>

                        <div class="text title-animation">
                            <h4>Our Services</h4>
                        </div>
                    </div>
                    <h2 class="sec-title__title title-animation">We Provide Best Service</h2>
                </div>

                <div class="row">
                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft mb-4" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-1"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Personalized Property Consultation</a></h2>
                                <p>Helping investors choose the right Dubai project based on budget, goals, and risk appetite.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->

                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight mb-4" data-wow-delay="100ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-2"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Investment Strategy & Portfolio Guidance</a></h2>
                                <p>Advising clients on high-yield rentals, long-term appreciation, and safe investment choices.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->

                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft mb-4" data-wow-delay="200ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-1"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Market Research & Insights</a></h2>
                                <p>Providing real-time market analysis, pricing trends, area recommendations, and ROI projections.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->

                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft mb-4" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-2"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Rental Income & ROI Planning</a></h2>
                                <p>Helping clients select properties with strong rental potential and future value growth.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->

                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight mb-4" data-wow-delay="100ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-1"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Holiday Home & Lifestyle Property Guidance</a></h2>
                                <p>Assisting buyers looking for second homes, vacation homes, or luxury lifestyle properties in Dubai.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->

                    <!--Start Services Four Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft mb-4" data-wow-delay="200ms"
                        data-wow-duration="1500ms">
                        <div class="services-four__single h-100">
                            <div class="services-four__single-icon">
                                <span class="icon-house-2"></span>
                            </div>
                            <div class="services-four__single-content">
                                <h2><a href="#">Transparent, Honest Advisory</a></h2>
                                <p>No push selling — clear communication, factual guidance, and trustworthy support.</p>
                                <div class="btn-box">
                                    <a href="#">View more <span class="icon-plus"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Four Single-->
                </div>
            </div>
        </section>
        <!--End Services Four-->
		<!--Start Counter One-->
        <section class="counter-one counter-one--two">
            <div class="shape1 scale"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape2 float-bob-x"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape3 rotated-style2"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape4 float-bob-y"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape5 rotated-style2"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape6 float-bob-x"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="shape7 scale"><img src="assets/images/shapes/counter-v2-shape1.png" alt=""></div>
            <div class="container">
                <div class="row">
                    <!--Start Counter One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="counter-one__single">
                            <div class="counter-one__single-inner">
                                <div class="counter-one__single-icon">
                                    <span class="icon-trophy"></span>
                                </div>

                                <div class="counter-one__single-content">
                                    <div class="count-box">
                                        <h2 class="count-text" data-stop="655" data-speed="1500">00</h2>
                                        <span class="k">k</span>
                                        <span class="plus">+</span>
                                    </div>
                                    <p>Awards Win</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Counter One Single-->

                    <!--Start Counter One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="counter-one__single">
                            <div class="counter-one__single-inner">
                                <div class="counter-one__single-icon">
                                    <span class="icon-verification"></span>
                                </div>

                                <div class="counter-one__single-content">
                                    <div class="count-box">
                                        <h2 class="count-text" data-stop="415" data-speed="1500">00</h2>
                                        <span class="k">k</span>
                                    </div>
                                    <p>Completed Project</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Counter One Single-->

                    <!--Start Counter One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="counter-one__single">
                            <div class="counter-one__single-inner">
                                <div class="counter-one__single-icon">
                                    <span class="icon-customer-review"></span>
                                </div>

                                <div class="counter-one__single-content">
                                    <div class="count-box">
                                        <h2 class="count-text" data-stop="898" data-speed="1500">00</h2>
                                        <span class="k">k</span>
                                        <span class="plus">+</span>
                                    </div>
                                    <p>Happy Clients</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Counter One Single-->

                    <!--Start Counter One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="counter-one__single style2">
                            <div class="counter-one__single-inner">
                                <div class="counter-one__single-icon">
                                    <span class="icon-project-plan"></span>
                                </div>

                                <div class="counter-one__single-content">
                                    <div class="count-box">
                                        <h2 class="count-text" data-stop="558" data-speed="1500">00</h2>
                                        <span class="k">k</span>
                                        <span class="plus">+</span>
                                    </div>
                                    <p>Finish The Job</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Counter One Single-->
                </div>
            </div>
        </section>
        <!--End Counter One-->

 <!--Start About Five-->
        <section class="about-five">
            <div class="shape1 float-bob-x"><img src="assets/images/shapes/about-v5-shape1.png" alt=""></div>
            <div class="container">
                <div class="row">
                    <!--Start About Five Img-->
                    <div class="col-xl-5 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="about-five__img clearfix">
                            <div class="about-five__img1">
                                <div class="about-five__img1-inner">
								<img src="assets/img/builders-img.jpeg">

                                </div>
                                
                            </div>
                           
                        </div>
                    </div>
                    <!--End About Five Img-->

                    <!--Start About Five Content-->
                    <div class="col-xl-7 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="about-five__content">
                            <div class="sec-title sec-title-animation animation-style2">
                                <div class="sec-title__tagline">
                                    <div class="icon-box">
                                        <span class="icon-household"></span>
                                    </div>

                                    <div class="text title-animation">
                                        <h4>Why Choose Us</h4>
                                    </div>
                                </div>
                                <h2 class="sec-title__title title-animation">Why Work With Manraj?
                                </h2>
                            </div>

                            <div class="about-five__content-text1">
                                <p>I combine deep knowledge of the Dubai market with a clear understanding of the Indian investor mindset. My approach is fully personalized — every project I recommend matches your goals, budget, and risk level. With strong connections to Dubai’s top developers, you get access to exclusive launches, priority inventory, and better payment plans.
<br>
I believe in complete transparency, simplifying the entire process so you make decisions with confidence. Whether you’re looking for rental returns, long-term appreciation, or a holiday home, I guide you end-to-end with clarity, honesty, and real market expertise.</p>
                            </div>

                            <div class="about-five__content-text2">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-6 col-md-6">
                                        <div class="about-five__content-text2-single">
                                           <ul class="about-four__content-list">
                                    <li>
                                        <p><span class="icon-checkmark"></span> Deep expertise in the Dubai real estate market</p>
                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Strong understanding of Indian investor needs & mindset</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Fully personalized property recommendations</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Access to exclusive projects & early launches</p>

                                    </li>
                                    <li>
                                        <p><span class="icon-checkmark"></span> Priority inventory and better payment plans</p>
                                    </li>
                                </ul>
                                        </div>
                                    </div>


                                </div>
                            </div>

                            <div class="about-five__content-bottom">
                                <div class="btn-box">
                                    <a class="thm-btn" href="#">Contact Us
                                        <i class="icon-next"></i>
                                        <span class="hover-btn hover-bx"></span>
                                        <span class="hover-btn hover-bx2"></span>
                                        <span class="hover-btn hover-bx3"></span>
                                        <span class="hover-btn hover-bx4"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About Five Content-->
                </div>
            </div>
        </section>
        <!--End About Five-->
		<!--Start Why Choose Two-->
        <section class="why-choose-two">
            <div class="why-choose-two__bg"
                style="background-image: url(assets/img/builders-img-1.jpeg);"></div>
            
            <div class="container clearfix">
                <div class="why-choose-two__inner">
                    <div class="why-choose-two__content">
                        <div class="sec-title sec-title-animation animation-style2">
                            <div class="sec-title__tagline">
                                
                            </div>
                            <h2 class="sec-title__title title-animation">Invest in Dubai — Guided by Someone Who Knows It Best: Mannraj Siing
                            </h2>
                        </div>

                        <div class="row filter-layout masonary-layout">
                            <!--Start Why Choose Two Single-->
                            <div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single text-center">
                                   

                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">Tax-free income on rentals & capital gains</a></h2>
                                        
                                    </div>
                                </div>
                            </div>
                            <!--End Why Choose Two Single-->

                            <!--Start Why Choose Two Single-->
                            <div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single mt30 text-center">
                                    
                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">15–20% annual appreciation in top communities</a></h2>
                                        
                                    </div>
                                </div>
                            </div>
                            <!--End Why Choose Two Single-->

                            <!--Start Why Choose Two Single-->
                            <div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single text-center">
                                   

                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">7–10% rental yields (among the highest globally)</a></h2>
                                       
                                    </div>
                                </div>
                            </div>
                            <!--End Why Choose Two Single-->

                            <!--Start Why Choose Two Single-->
                            <div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single text-center">
                                    

                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">World-class infrastructure & global connectivity</a></h2>
                                        
                                    </div>
                                </div>
                            </div>

							<div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single text-center">
                                    

                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">100% safe, transparent property laws</a></h2>
                                        
                                    </div>
                                </div>
                            </div>

							<div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                                <div class="why-choose-two__single text-center">
                                    

                                    <div class="why-choose-two__single-content">
                                        <h2><a href="#">Residency options with property investment</a></h2>
                                        
                                    </div>
                                </div>
                            </div>
                            <!--End Why Choose Two Single-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Why Choose Two-->
        
<!--Start Contact One -->
        <section class="contact-one">
            <div class="contact-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                style="background-image: url(assets/images/backgrounds/contact-v1-bg.jpg);">
            </div>
            <div class="container">
                <div class="sec-title text-center sec-title-animation animation-style1">
                    <div class="sec-title__tagline center">
                        <div class="icon-box">
                            <span class="icon-household"></span>
                        </div>

                        <div class="text title-animation">
                            <h4> Contact Us</h4>
                        </div>
                    </div>
                    <h2 class="sec-title__title title-animation">Feel free to contact with us for <br> any kind of
                        query.</h2>
                </div>

                <div class="contact-one__inner">
                    <div class="row">
                        <!--Start Contact One Form-->
                        <div class="col-xl-8 col-lg-8">
                            <div class="contact-one__form">
                                <form class="contact-form-validated contact-one__form-box"
                                    action="#" method="post" novalidate="novalidate">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="text" name="name" placeholder="Name" required="">
                                                <div class="icon"><span class="icon-people"></span></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="email" name="email" placeholder="Email" required="">
                                                <div class="icon"><span class="icon-envelope"></span></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="text" name="Phone" placeholder="Phone" required="">
                                                <div class="icon"><span class="icon-call"></span></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <div class="select-box">
                                                    <select class="selectmenu wide">
                                                        <option selected="selected">Subject</option>
                                                        <option>Subject 01</option>
                                                        <option>Subject 02</option>
                                                        <option>Subject 03</option>
                                                        <option>Subject 04</option>
                                                        <option>Subject 05</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="input-box">
                                                <textarea name="message" placeholder="Message"></textarea>
                                                <div class="icon style2"><span class="fa fa-pencil"></span></div>
                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="contact-page__form-btn">
                                                <button type="submit" class="thm-btn">
                                                    Send us message
                                                    <i class="icon-next"></i>
                                                    <span class="hover-btn hover-bx"></span>
                                                    <span class="hover-btn hover-bx2"></span>
                                                    <span class="hover-btn hover-bx3"></span>
                                                    <span class="hover-btn hover-bx4"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="result"></div>
                            </div>
                        </div>
                        <!--End Contact One Form-->

                        <!--Start Contact One Contact Info -->
                        <div class="col-xl-4 col-lg-4">
                            <div class="contact-one__contact-info">
                                <div class="title-box">
                                    <h2>Contact Info</h2>
                                </div>

                                <ul class="contact-one__contact-info-list">
                                    <li class="contact-one__contact-info-list-item">
                                        <div class="icon-box">
                                            <span class="icon-placeholder"></span>
                                        </div>

                                        <div class="text-box">
                                            <p>-----------------</p>
                                        </div>
                                    </li>

                                    <li class="contact-one__contact-info-list-item">
                                        <div class="icon-box">
                                            <span class="icon-phone-call"></span>
                                        </div>

                                        <div class="text-box">
                                            <p><a href="#">------------</a></p>
                                            <p><a href="#">-------------</a></p>
                                        </div>
                                    </li>

                                    <li class="contact-one__contact-info-list-item">
                                        <div class="icon-box">
                                            <span class="icon-mail"></span>
                                        </div>

                                        <div class="text-box">
                                            <p><a href="#">-----------</a></p>
                                            <p><a href="#">------------------</a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!--End Contact One Contact Info -->
                    </div>
                </div>
            </div>
        </section>
        <!--End Contact One -->


        
        
        




<?= $this->endSection() ?>