<?php

namespace Modules\Frontend\Controllers;
use Modules\Frontend\Controllers\BaseController;
use Modules\Frontend\Models\FrontendCrudModel;

    class Home extends BaseController
    {
        /* ======================
        Home Page
        ====================== */
        public function index()
        {
           
            
            return view('Modules\Frontend\Views\Pages\home');
        }
        
        
    }