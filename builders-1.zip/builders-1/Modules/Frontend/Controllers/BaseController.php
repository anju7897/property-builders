<?php
namespace Modules\Frontend\Controllers;
use App\Controllers\BaseController as AppBaseController;
use Modules\Frontend\Models\FrontendCrudModel;

class BaseController extends AppBaseController
{
    protected $menuCategories = [];
    protected $cartCount = 0;


    public function __construct()
    {
       
    }
}