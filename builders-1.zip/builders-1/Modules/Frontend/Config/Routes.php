<?php

    $routes->group('/', ['namespace' => 'Modules\Frontend\Controllers'], function($routes) {
        
        /* ======================== START - WEBSITE ROUTE  ======================= */
        
        // Default Home Page
        $routes->get('', 'Home::index');

        // Au Pair 
        $routes->get('au-pair', 'Home::auPair');

        // Host Family
        $routes->get('host-family', 'Home::hostFamily');

        //  News And Resources
        $routes->get('news-and-resources', 'Home::newsAndResources');

        // How it Works
        $routes->get('how-it-works', 'Home::howItWorks');

        // Safety And Security
        $routes->get('safety-and-security', 'Home::safetyAndSecurity');

        // Au Pair Profile
        $routes->get('au-pair-profile', 'Home::AuPairProfile');


        // Host Family Profile
        $routes->get('host-family-profile', 'Home::HostFamilyProfile');
        $routes->get('login', 'User::userLogin');
        $routes->post('login', 'User::userLogin');

        $routes->get('registration', 'User::userRegistration');
        $routes->post('registration', 'User::userRegistration');

        $routes->get('user/logout', 'User::logout');        



         $routes->get('nanny/dashboard', 'NannyDashboard::nannyDashboard');
         $routes->get('hostFamily/dashboard', 'HostFamilyDashboard::hostFamilyDashboard');

         $routes->get('nanny/update-profile', 'NannyDashboard::updateProfile');
    });

?>
