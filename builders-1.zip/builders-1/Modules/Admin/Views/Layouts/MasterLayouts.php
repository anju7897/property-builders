<!DOCTYPE html>
<html lang="en" data-layout-mode="light_mode">
<head>
	<!-- Meta Tags -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="index, follow">
    <title><?= isset($pageTitle) && $pageTitle ? $pageTitle : 'Admin' ?></title>

	<script src="<?= base_url('assets/admin') ?>/js/theme-script.js" ></script>	

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/admin/vijayaagni/logo/' . session('favIcon')); ?>">

	<!-- Apple Touch Icon -->
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/admin') ?>/img/apple-touch-icon.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/bootstrap.min.css">

	<!-- Datetimepicker CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/bootstrap-datetimepicker.min.css">

	<!-- animation CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/animate.css">

	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/feather.css">

	<!-- Summernote CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/summernote/summernote-bs4.min.css">

	<!-- Select2 CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/select2/css/select2.min.css">

	<!-- Bootstrap Tagsinput CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css">

	<!-- Datatable CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/dataTables.bootstrap5.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/fontawesome/css/all.min.css">

	<!-- Tabler Icon CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/tabler-icons/tabler-icons.css">

	<!-- Color Picker Css -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/%40simonwep/pickr/themes/nano.min.css">
	
	

	<!-- Form Date PIckers CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/flatpickr/flatpickr.css">
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/bootstrap-datepicker/bootstrap-datepicker.css">
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/jquery-timepicker/jquery-timepicker.css">
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/pickr/pickr-themes.css">
    
    <!-- animation CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/animate.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css" integrity="sha512-bYPO5jmStZ9WI2602V2zaivdAnbAhtfzmxnEGh9RwtlI00I9s8ulGe4oBa5XxiC6tCITJH/QG70jswBhbLkxPw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-bs4.min.js"></script>
    


    <style>
      .sidebar-contact .toggle-theme{
          display:none;
      } 
    </style>
</head>

<body>
	<!-- Add SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            <?php if (session()->getFlashdata('success')): ?>
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: '<?= session()->getFlashdata('success') ?>',
                    showConfirmButton: false,
                    timer: 3000
                });
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                Swal.fire({
                    position: 'top-end',
                    icon: 'error',
                    title: '<?= session()->getFlashdata('error') ?>',
                    showConfirmButton: false,
                    timer: 3000
                });
            <?php endif; ?>
        });
    </script>
	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<!-- Header -->
		<div class="header">
			<div class="main-header">

				<!-- Logo -->
				<div class="header-left active">
					<!-- Normal Logo -->
					<a href="<?= base_url('admin/dashboard') ?>" class="logo logo-normal">
						<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('logo')) ?>" width="80" height="50" alt="Logo">
					</a>

					<!-- White Logo (for dark background) -->
					<a href="<?= base_url('/') ?>" class="logo logo-white">
						<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('logo')) ?>" width="80" height="50" alt="White Logo">
					</a>

					<!-- Small Logo (favicon or mini icon) -->
					<a href="<?= base_url('/') ?>" class="logo logo-small">
						<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('favIcon')) ?>" width="40" height="40" alt="Favicon">
					</a>
				</div>
				<!-- /Logo -->


				<a id="mobile_btn" class="mobile_btn" href="#sidebar">
					<span class="bar-icon">
						<span></span>
						<span></span>
						<span></span>
					</span>
				</a>

				<!-- Header Menu -->
				<ul class="nav user-menu">

					<!-- Search -->
					<li class="nav-item nav-searchinputs">
						<div class="top-nav-search">
							<a href="javascript:void(0);" class="responsive-search">
								<i class="fa fa-search"></i>
							</a>
							<form action="#" class="dropdown">
								<div class="searchinputs input-group dropdown-toggle" id="dropdownMenuClickable" data-bs-toggle="dropdown" data-bs-auto-close="outside">
									<input type="text" placeholder="Search">
									<div class="search-addon">
										<span><i class="ti ti-search"></i></span>
									</div>
									<span class="input-group-text">
										<kbd class="d-flex align-items-center"><img src="<?= base_url('assets/admin') ?>/img/icons/command.svg" alt="img" class="me-1">K</kbd>
									</span>
								</div>
								
							</form>
						</div>
					</li>
					<!-- /Search -->			

				
					<!-- Flag -->
					<li class="nav-item dropdown has-arrow flag-nav nav-item-box">
						<a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="javascript:void(0);"
							role="button">
							<img src="<?= base_url('assets/admin') ?>/img/flags/us-flag.svg" alt="Language" class="img-fluid">
						</a>
						<div class="dropdown-menu dropdown-menu-right">
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="<?= base_url('assets/admin') ?>/img/flags/english.svg" alt="Img" height="16">English
							</a>
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="<?= base_url('assets/admin') ?>/img/flags/arabic.svg" alt="Img" height="16">Arabic
							</a>
						</div>
					</li>
					<!-- /Flag -->

					<li class="nav-item nav-item-box">
						<a href="javascript:void(0);" id="btnFullscreen">
							<i class="ti ti-maximize"></i>
						</a>
					</li>
				
					<!-- Notifications -->
					<li class="nav-item dropdown nav-item-box">
						<a href="javascript:void(0);" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
							<i class="ti ti-bell"></i>
						</a>
						<div class="dropdown-menu notifications">
							<div class="topnav-dropdown-header">
								<h5 class="notification-title">Notifications</h5>
								<a href="javascript:void(0)" class="clear-noti">Mark all as read</a>
							</div>
							<div class="noti-content">
								<ul class="notification-list">
									<li class="notification-message">
										<a href="activities.html">
											<div class="media d-flex">
												<span class="avatar flex-shrink-0">
													<img alt="Img" src="<?= base_url('assets/admin') ?>/img/profiles/avatar-13.jpg">
												</span>
												<div class="flex-grow-1">
													<p class="noti-details"><span class="noti-title">James Kirwin</span> confirmed his order.  Order No: #78901.Estimated delivery: 2 days</p>
													<p class="noti-time">4 mins ago</p>
												</div>
											</div>
										</a>
									</li>
									
								</ul>
							</div>
							<div class="topnav-dropdown-footer d-flex align-items-center gap-3">
								<a href="#" class="btn btn-secondary btn-md w-100">Cancel</a>
								<a href="activities.html" class="btn btn-primary btn-md w-100">View all</a>
							</div>
						</div>
					</li>
					<!-- /Notifications -->

					<li class="nav-item nav-item-box">
						<a href="general-settings.html"><i class="ti ti-settings"></i></a>
					</li>
					<li class="nav-item dropdown has-arrow main-drop profile-nav">
						<a href="javascript:void(0);" class="nav-link userset" data-bs-toggle="dropdown">
							<span class="user-info p-0">
								<span class="user-letter">
									<img src="<?= base_url('assets/admin') ?>/img/profiles/avator1.jpg" alt="Img" class="img-fluid">
								</span>
							</span>
						</a>
						<div class="dropdown-menu menu-drop-user">
							<div class="profileset d-flex align-items-center">
								<span class="user-img me-2">
									<img src="<?= base_url('assets/admin') ?>/img/profiles/avator1.jpg" alt="Img">
								</span>
								<div>
									<h6 class="fw-medium">John Smilga</h6>
									<p>Admin</p>
								</div>
							</div>
							<a class="dropdown-item" href="profile.html"><i class="ti ti-user-circle me-2"></i>MyProfile</a>
							<a class="dropdown-item" href="general-settings.html"><i class="ti ti-settings-2 me-2"></i>Settings</a>
							<hr class="my-2">
							<a class="dropdown-item logout pb-0" href="<?= base_url('admin/logout');?>"><i class="ti ti-logout me-2"></i>Logout</a>
						</div>
					</li>
				</ul>
				<!-- /Header Menu -->

				<!-- Mobile Menu -->
				<div class="dropdown mobile-user-menu">
					<a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
						aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
					<div class="dropdown-menu dropdown-menu-right">
						<a class="dropdown-item" href="profile.html">My Profile</a>
						<a class="dropdown-item" href="general-settings.html">Settings</a>
						<a class="dropdown-item" href="<?= base_url('admin/logout') ?>">Logout</a>
					</div>
				</div>
				<!-- /Mobile Menu -->
			</div>
		</div>
		<!-- /Header -->

		<!-- Sidebar -->
		<div class="sidebar" id="sidebar">
			<!-- Logo -->
			<div class="sidebar-logo">
				<a href="<?= base_url('admin/dashboard') ?>" class="logo logo-normal">
					<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('logo')); ?>" alt="Img">
				</a>
				<a href="<?= base_url('admin/dashboard') ?>" class="logo logo-white">
					<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('logo')); ?>" alt="Img">
				</a>
				<a href="<?= base_url('admin/dashboard') ?>" class="logo-small">
					<img src="<?= base_url('assets/admin/vijayaagni/logo/' . session('favIcon')); ?>" alt="Img">
				</a>
				<a id="toggle_btn" href="javascript:void(0);">
					<i data-feather="chevrons-left" class="feather-16"></i>
				</a>
			</div>
			<!-- /Logo -->
			<div class="modern-profile p-3 pb-0">
				<div class="text-center rounded bg-light p-3 mb-4 user-profile">
					<div class="avatar avatar-lg online mb-3">
						<img src="<?= base_url('assets/admin') ?>/img/customer/customer15.jpg" alt="Img" class="img-fluid rounded-circle">
					</div>
					<h6 class="fs-14 fw-bold mb-1">Adrian Herman</h6>
					<p class="fs-12 mb-0">System Admin</p>
				</div>
				<div class="sidebar-nav mb-3">
					<ul class="nav nav-tabs nav-tabs-solid nav-tabs-rounded nav-justified bg-transparent" role="tablist">
						<li class="nav-item"><a class="nav-link active border-0" href="#">Menu</a></li>
						<li class="nav-item"><a class="nav-link border-0" href="chat.html">Chats</a></li>
						<li class="nav-item"><a class="nav-link border-0" href="email.html">Inbox</a></li>
					</ul>
				</div>
			</div>
			<div class="sidebar-header p-3 pb-0 pt-2">
				<div class="text-center rounded bg-light p-2 mb-4 sidebar-profile d-flex align-items-center">
					<div class="avatar avatar-md onlin">
						<img src="<?= base_url('assets/admin') ?>/img/customer/customer15.jpg" alt="Img" class="img-fluid rounded-circle">
					</div>
					<div class="text-start sidebar-profile-info ms-2">
						<h6 class="fs-14 fw-bold mb-1">Adrian Herman</h6>
						<p class="fs-12">System Admin</p>
					</div>
				</div>
				<div class="d-flex align-items-center justify-content-between menu-item mb-3">
					<div>
						<a href="index.html" class="btn btn-sm btn-icon bg-light">
							<i class="ti ti-layout-grid-remove"></i>
						</a>
					</div>
					<div>
						<a href="chat.html" class="btn btn-sm btn-icon bg-light">
							<i class="ti ti-brand-hipchat"></i>
						</a>
					</div>
					<div>
						<a href="email.html" class="btn btn-sm btn-icon bg-light position-relative">
							<i class="ti ti-message"></i>
						</a>
					</div>
					<div class="notification-item">
						<a href="activities.html" class="btn btn-sm btn-icon bg-light position-relative">
							<i class="ti ti-bell"></i>
							<span class="notification-status-dot"></span>
						</a>
					</div>
					<div class="me-0">
						<a href="general-settings.html" class="btn btn-sm btn-icon bg-light">
							<i class="ti ti-settings"></i>
						</a>
					</div>
				</div>
			</div>
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu">
					<ul>
						<li class="submenu-open">
							<h6 class="submenu-hdr">Main</h6>
							<ul>
								<li class="submenu">
									<a href="<?= base_url('admin/dashboard') ?>" class="active"><i class="ti ti-layout-grid fs-16 me-2"></i><span>Dashboard</span><span></span></a>
									
								</li>
								
								<!-- Blog -->
								<li class="submenu <?= ($pageName == 'add-blog-category' ||$pageName == 'blog-category-list' || $pageName == 'blog-tags' || $pageName == 'blog-tags-list' || $pageName == 'add-blog-post' || $pageName == 'post-list' ) ? 'open' : '' ?>">
									<a href="javascript:void(0);"><i class="ti ti-notebook fs-16 me-2"></i><span>Blog</span><span class="menu-arrow"></span></a>
									<ul style="<?= ($pageName == 'add-blog-category' || $pageName == 'blog-category-list' || $pageName == 'blog-tags' ||$pageName == 'blog-tags-list' || $pageName == 'add-blog-post' || $pageName == 'post-list') ? 'display: block;' : '' ?>">
										<li><a href="<?= base_url('admin/blog/add-blog-category') ?>" class="<?= ($pageName == 'add-blog-category') ? 'active' : '' ?>">Add Category</a></li>
										<li><a href="<?= base_url('admin/blog/blog-category-list') ?>" class="<?= ($pageName == 'blog-category-list') ? 'active' : '' ?>">Category List</a></li>
										<li><a href="<?= base_url('admin/blog/add-blog-tags') ?>" class="<?= ($pageName == 'blog-tags') ? 'active' : '' ?>">Tags</a></li>
										<li><a href="<?= base_url('admin/blog/blog-tags-list') ?>" class="<?= ($pageName == 'blog-tags-list') ? 'active' : '' ?>">Tags List</a></li>
										<li><a href="<?= base_url('admin/blog/add-blog-post') ?>" class="<?= ($pageName == 'add-blog-post') ? 'active' : '' ?>">Add Post</a></li>
										<li><a href="<?= base_url('admin/blog/post-list') ?>" class="<?= ($pageName == 'post-list') ? 'active' : '' ?>">Post List</a></li>
									</ul>
								</li>
								
								<!-- Category -->
								<li class="submenu <?= ($pageName == 'add-country' ||$pageName == 'country-list') ? 'open' : '' ?>">
									<a href="javascript:void(0);"><i class="ti ti-layout-grid fs-16 me-2"></i><span>Country</span><span class="menu-arrow"></span></a>
									<ul style="<?= ($pageName == 'add-country' || $pageName == 'country-list') ? 'display: block;' : '' ?>">
										<li><a href="<?= base_url('admin/country/add-country') ?>" class="<?= ($pageName == 'add-country') ? 'active' : '' ?>">Add Country</a></li>
										<li><a href="<?= base_url('admin/country/country-list') ?>" class="<?= ($pageName == 'country-list') ? 'active' : '' ?>">Country List</a></li>
										
									</ul>
								</li>
								

								<!-- Main Section -->
								<li class="submenu <?= ($pageName == 'add-banner' ||$pageName == 'product-list') ? 'open' : '' ?>">
									<a href="javascript:void(0);"><i class="ti ti-layout-grid fs-16 me-2"></i><span>Banner</span><span class="menu-arrow"></span></a>
									<ul style="<?= ($pageName == 'add-banner' || $pageName == 'product-list') ? 'display: block;' : '' ?>">
										<li><a href="<?= base_url('admin/banner/add-banner') ?>" class="<?= ($pageName == 'add-banner') ? 'active' : '' ?>">Add Banner</a></li>
										<li><a href="<?= base_url('admin/banner/list-banner') ?>" class="<?= ($pageName == 'Banner-list') ? 'active' : '' ?>">Banner List</a></li>
																			

									</ul>
								</li>
								<!-- Product -->
								<li class="submenu <?= ($pageName == 'add-product' ||$pageName == 'product-list') ? 'open' : '' ?>">
									<a href="javascript:void(0);"><i class="ti ti-layout-grid fs-16 me-2"></i><span>Country</span><span class="menu-arrow"></span></a>
									<ul style="<?= ($pageName == 'add-product' || $pageName == 'product-list') ? 'display: block;' : '' ?>">
										<li><a href="<?= base_url('admin/product/add-product') ?>" class="<?= ($pageName == 'add-product') ? 'active' : '' ?>">Add Country</a></li>
										<li><a href="<?= base_url('admin/product/product-list') ?>" class="<?= ($pageName == 'product-list') ? 'active' : '' ?>">Country List</a></li>
										
									</ul>
								</li>



							
																			
							</ul>
						</li>				
						
    					<li class="submenu <?= ($pageName == 'system-setting-admin') ? 'open' : '' ?>">
                        	<a href="javascript:void(0);" >
                        		<i class="ti ti-settings fs-16 me-2"></i>
                        		<span>Settings</span>
                        		<span class="menu-arrow"></span>
                        	</a>
                        	<ul style="<?= ($pageName == 'system-setting-admin') ? 'display: block;' : '' ?>">
                        		<li><a href="<?= base_url('admin/profile'); ?>" class="<?= ($pageName == 'system-setting-admin') ? 'active' : '' ?>">Profile</a></li>
                        	</ul>
                        </li>
                        
                        <li>
                          <a href="<?= base_url('admin/logout'); ?>" id="logoutBtn">
                            <i class="ti ti-logout fs-16 me-2"></i><span>Logout</span>
                          </a>
                        </li>



						
					</ul>
				</div>
			</div>
		</div>
		<!-- /Sidebar -->

		<!-- Horizontal Sidebar -->
		<div class="sidebar sidebar-horizontal" id="horizontal-menu">
			<div id="sidebar-menu-3" class="sidebar-menu">
				<div class="main-menu">
					<ul class="nav-menu">
						<li class="submenu">
							<a href="#"><i class="ti ti-layout-grid fs-16 me-2"></i><span> Main Menu</span> <span class="menu-arrow"></span></a>
							<ul>
								<li class="submenu">
									<a href="javascript:void(0);" class="active subdrop"><span>Dashboard</span> <span class="menu-arrow"></span></a>
									<ul>
										<li><a href="<?= base_url('admin/dashboard') ?>">Admin Dashboard</a></li>										
									</ul>
								</li>
								<li class="submenu">
									<a href="javascript:void(0);"><span>Branch</span><span class="menu-arrow"></span></a>
									<ul>
										<li><a href="<?= base_url('admin/add-branch') ?>">Add Branch</a></li>
										<li><a href="<?= base_url('admin/branch-list') ?>">List Branch</a></li>										
									</ul>
								</li>							
								
							</ul>
						</li>
						
						
					
						<li class="submenu">
							<a href="javascript:void(0);"><i class="ti ti-settings fs-16 me-2"></i><span>Settings</span><span class="menu-arrow"></span></a>
							<ul>
								<li class="submenu">
									<a href="javascript:void(0);"><span>Settings</span><span class="menu-arrow"></span></a>
									<ul>
										<li><a href="#">Profile</a></li>
										
									</ul>
								</li>
							
								<li>
									<a href="signin.html"><span>Logout</span> </a>
								</li>
							</ul>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<!-- /Horizontal Sidebar -->

	

		<div class="page-wrapper">
			<div class="content">
				

            <!-- ****************************** Start adding content *********************** -->
                <?= $this->renderSection('content') ?>
                
            <!-- ****************************** Start adding content *********************** -->
			</div>
			
			<div class="copyright-footer d-flex align-items-center justify-content-between border-top bg-white gap-3 flex-wrap">
				<p class="fs-13 text-gray-9 mb-0"><?= date('Y') ?> &copy; MecGear. All Right Reserved</p>
				<p>Designed & Developed By <a href="javascript:void(0);" class="link-primary">Efficient India</a></p>
			</div>
		</div>

	</div>
	<!-- /Main Wrapper -->

	<!-- jQuery -->
	<script src="<?= base_url('assets/admin') ?>/js/jquery-3.7.1.min.js" ></script>

	<!-- Feather Icon JS -->
	<script src="<?= base_url('assets/admin') ?>/js/feather.min.js" ></script>
	<!-- Daterangepikcer CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/admin') ?>/plugins/daterangepicker/daterangepicker.css">


	<!-- Slimscroll JS -->
	<script src="<?= base_url('assets/admin') ?>/js/jquery.slimscroll.min.js" ></script>

	<!-- Datatable JS -->
	<script src="<?= base_url('assets/admin') ?>/js/jquery.dataTables.min.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/js/dataTables.bootstrap5.min.js" ></script>

	<!-- Bootstrap Core JS -->
	<script src="<?= base_url('assets/admin') ?>/js/bootstrap.bundle.min.js" ></script>

	<!-- Select2 JS -->
	<script src="<?= base_url('assets/admin') ?>/plugins/select2/js/select2.min.js" ></script>

	<!-- Summernote JS -->
	<script src="<?= base_url('assets/admin') ?>/plugins/summernote/summernote-bs4.min.js" ></script>

	<!-- Datetimepicker JS -->
	<script src="<?= base_url('assets/admin') ?>/js/moment.min.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/js/bootstrap-datetimepicker.min.js" ></script>

	<!-- Bootstrap Tagsinput JS -->
	<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js" ></script>

	<!-- Color Picker JS -->
	<script src="<?= base_url('assets/admin') ?>/plugins/%40simonwep/pickr/pickr.es5.min.js" ></script>

	<!-- Custom JS -->
	<script src="<?= base_url('assets/admin') ?>/js/theme-colorpicker.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/js/script.js" ></script>
	<!-- Form Date PIckers JS -->
	<script src="<?= base_url('assets/admin') ?>/plugins/moment/moment.min.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/flatpickr/flatpickr.js"></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap-datepicker/bootstrap-datepicker.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/daterangepicker/daterangepicker.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/jquery-timepicker/jquery-timepicker.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/pickr/pickr.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/plugins/%40simonwep/pickr/pickr.min.js" ></script>
	<script src="<?= base_url('assets/admin') ?>/js/forms-pickers.js" ></script>
	
	<script>
	    $('#editMainCategory').change(function(){
    var mainCatId = $(this).val();
    if(mainCatId != ''){
        $.ajax({
            url: "<?= base_url('admin/product/child-category') ?>",
            method: "POST",
            data: { parentId: mainCatId },
            success: function(response){
                var data = JSON.parse(response);
                var html = '<option value="">Select Child Category</option>';
                if(data.length > 0){
                    for(var i=0; i<data.length; i++){
                        html += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
                    }
                }
                $('#editChildCategory').html(html);
            }
        });
    }else{
        $('#editChildCategory').html('<option value="">Select Child Category</option>');
    }
});

// Page Load ke time auto child load
$(document).ready(function(){
    var mainCatId = $('#editMainCategory').val(); // Selected Main Category
    var selectedChildId = $('#selectedChildCategory').val(); // Pre-selected Child Category
    if(mainCatId != ''){
        $.ajax({
            url: "<?= base_url('admin/product/child-category') ?>",
            method: "POST",
            data: { parentId: mainCatId },
            success: function(response){
                var data = JSON.parse(response);
                var html = '<option value="">Select Child Category</option>';
                if(data.length > 0){
                    for(var i=0; i<data.length; i++){
                        var selected = (data[i].id == selectedChildId) ? 'selected' : '';
                        html += '<option value="'+data[i].id+'" '+selected+'>'+data[i].name+'</option>';
                    }
                }
                $('#editChildCategory').html(html);
            }
        });
    }
});

	</script>
    
     <?= $this->renderSection('js') ?>
    </body>
    
    
    <!-- Logout -->
	<script>
      document.getElementById('logoutBtn').addEventListener('click', function (e) {
        e.preventDefault(); // Default logout link ko rokna
    
        Swal.fire({
          title: 'Are you sure?',
          text: "You want to logout!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, logout!',
          cancelButtonText: 'No'
        }).then((result) => {
          if (result.isConfirmed) {
            // Agar "Yes" pe click kiya
            window.location.href = this.href; // logout URL pr redirect
          }
        });
      });
    </script>
    
    <script>
        $('#editMainCategory').change(function(){
            var mainCatId = $(this).val();
            if(mainCatId != ''){
                $.ajax({
                    url: "<?= base_url('admin/product/get-child-category') ?>",
                    method: "POST",
                    data: { parentId: mainCatId },
                    success: function(response){
                        var data = JSON.parse(response);
                        var html = '<option value="">Select Child Category</option>';
                        if(data.length > 0){
                            for(var i=0; i<data.length; i++){
                                html += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
                            }
                        }
                        $('#editChildCategory').html(html);
                    }
                });
            }else{
                $('#editChildCategory').html('<option value="">Select Child Category</option>');
            }
        });
    </script>
    

    
    
    
   
</html>