<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<style>
.longDescription .note-editable {
    min-height: 390px !important;
}
</style>

<!-- Breadcrumbs -   START -->
<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?= $pageTitle ?></h4>

        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
        </li>
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                    class="ti ti-chevron-up"></i></a>
        </li>
    </ul>
    <div class="page-btn mt-0">
        <a href="<?= base_url("admin/category/category-list") ?>" class="btn btn-secondary">
            <i data-feather="arrow-left" class="me-2"></i>Back to Category List
        </a>
    </div>
</div>

<!-- Breadcrumbs -   END -->

<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">
            Edit Product Details
        </h4>
    </div>
    <div class="card-body">
        <form action="<?= base_url('admin/product/update-product/'.$product->id); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $product->id ?>">
            <div class="row">
                <!-- Product Name -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Product Name<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="name" placeholder="Enter Product Name"
                               value="<?= old('name', $product->name); ?>">
                        <p class="text-danger"><?= session("errors.name") ?></p>
                    </div>
                </div>
                <!-- Slug -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Slug<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="slug" placeholder="Enter Slug"
                               value="<?= old('slug', $product->slug); ?>">
                        <p class="text-danger"><?= session("errors.slug") ?></p>
                    </div>
                </div>
            </div>

            <div class="row py-2">
                <!-- SKU -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">SKU</label>
                        <input type="text" class="form-control" name="sku" placeholder="Enter SKU"
                               value="<?= old('sku', $product->sku); ?>" readonly>
                        <p class="text-danger"><?= session("errors.sku") ?></p>
                    </div>
                </div>
                <!-- Main Category -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Main Category<span class="text-danger ms-1">*</span></label>
                        <select name="mainCategory" id="editMainCategory" class="form-control">
                            <option value="">Select Main Category</option>
                            <?php foreach($getAllCategoryRecords as $mainCat): ?>
                                <option value="<?= $mainCat->id; ?>" <?= ($product->mainCategory == $mainCat->id) ? 'selected' : '' ?>>
                                    <?= esc($mainCat->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="text-danger"><?= session("errors.mainCategory") ?></p>
                    </div>
                </div>
            </div>

            <div class="row py-2">
                <!-- Child Category -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Child Category</label>
                        <select name="childCategory" id="editChildCategory" class="form-control">
                            <option value="">Select Child Category</option>
                            <!-- Will be populated by AJAX -->
                        </select>
                        <p class="text-danger"><?= session("errors.childCategory") ?></p>
                    </div>
                </div>
                
                <input type="hidden" id="selectedChildCategory" value="<?= $product->childCategory ?>">
                
                <!-- Brand -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Brand</label>
                        <select class="form-control" name="brandId">
                            <option value="">Select Brand</option>
                            <?php foreach($getAllBrand as $brand): ?>
                                <option value="<?= $brand->id ?>" <?= ($product->brandId == $brand->id) ? 'selected' : '' ?>><?= $brand->name ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="text-danger"><?= session("errors.brandId") ?></p>
                    </div>
                </div>
            </div>
            
            <div class="row py-2">
                <!-- Price -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Buying Price<span class="text-danger ms-1">*</span></label>
                        <input type="number" step="0.01" class="form-control" name="buyingPrice" placeholder="Enter Price"
                             value="<?= old('name', $product->buyingPrice); ?>">
                        <p class="text-danger"><?= session("errors.buyingPrice") ?></p>
                    </div>
                </div>

                <!-- Selling Price -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Selling Price<span class="text-danger ms-1">*</span></label>
                        <input type="number" step="0.01" class="form-control" name="sellingPrice" placeholder="Enter Selling Price"
                           value="<?= old('name', $product->sellingPrice); ?>">
                        <p class="text-danger"><?= session("errors.sellingPrice") ?></p>
                    </div>
                </div>
            </div>
            
            <div class="row py-2">
                
                <!-- Opening Stock -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Opening Stock<span class="text-danger ms-1">*</span></label>
                        <input type="number" step="0.01" class="form-control" name="stock" placeholder="Enter Stock"
                            value="<?= old('stock', $product->currentStock); ?>" readonly>
                        <p class="text-danger"><?= session("errors.stock") ?></p>
                    </div>
                </div>
                
                <!-- Tax Rate -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">GST Tax Rate (%)<span class="text-danger ms-1">*</span></label>
                        <select name="gst" id="gst" class="form-control">
                        <option value="">Select GST</option>
                        <?php if(!empty($getAllGst)): ?>
                            <?php foreach($getAllGst as $val): ?>
                                <option value="<?= $val->id; ?>" <?= ($val->gst == $product->gstName) ? 'selected' : '' ?>><?= esc($val->gst); ?> %</option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </select>
                        <p class="text-danger"><?= session("errors.gst") ?></p>
                    </div>
                </div>
                
            </div><br>
            
             <div class="row py-2">
                <!-- Weight -->
                <div class="col-sm-3 col-12">
                    <div class="mb-3">
                        <label class="form-label">Weight (kg)</label>
                        <input type="number" step="0.01" class="form-control" name="weight" placeholder="Enter Weight"
                            value="<?= old('weight',$product->weight); ?>">
                        <p class="text-danger"><?= session("errors.weight") ?></p>
                    </div>
                </div>

                <!-- Length -->
                <div class="col-sm-3 col-12">
                    <div class="mb-3">
                        <label class="form-label">Length (cm)</label>
                        <input type="number" step="0.01" class="form-control" name="length" placeholder="Enter Length"
                            value="<?= old('length', $product->length); ?>">
                        <p class="text-danger"><?= session("errors.length") ?></p>
                    </div>
                </div>

                <!-- Width -->
                <div class="col-sm-3 col-12">
                    <div class="mb-3">
                        <label class="form-label">Width (cm)</label>
                        <input type="number" step="0.01" class="form-control" name="width" placeholder="Enter Width"
                            value="<?= old('width', $product->width); ?>">
                        <p class="text-danger"><?= session("errors.width") ?></p>
                    </div>
                </div>

                <!-- Height -->
                <div class="col-sm-3 col-12">
                    <div class="mb-3">
                        <label class="form-label">Height (cm)</label>
                        <input type="number" step="0.01" class="form-control" name="height" placeholder="Enter Height"
                            value="<?= old('height', $product->height); ?>">
                        <p class="text-danger"><?= session("errors.height") ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Short Description -->
            <div class="row py-2">
                <div class="col-lg-12">
                    <div class="summer-description-box">
                        <label class="form-label" for="summernote">Short Description<span class="text-danger ms-1">*</span></label>
                        <textarea id="summernote" name="shortDescription" class="form-control"><?= old('shortDescription', $product->shortDescription); ?></textarea>
                        <p class="text-danger"><?= session("errors.shortDescription") ?></p>
                        <!--<p class="fs-14 mt-1">Maximum 60 Words</p>-->
                    </div>
                </div>
            </div>
            
            <!-- Long Description -->
            <div class="row py-2">
                <div class="col-lg-12">
                    <div class="longDescription">
                        <label class="form-label" for="summernote">Long Description<span class="text-danger ms-1">*</span></label>
                        <textarea id="longDescription" name="longDescription" class="form-control"><?= old('longDescription', $product->longDescription); ?></textarea>
                        <p class="text-danger"><?= session("errors.longDescription") ?></p>
                        <!--<p class="fs-14 mt-1">Maximum 60 Words</p>-->
                    </div>
                </div>
            </div>
            
           

            <div class="row py-2">
                <!-- Meta Title -->
                <div class="col-sm-12 col-12">
                    <div class="mb-3">
                        <label class="form-label">Meta Title</label>
                        <input type="text" class="form-control" name="metaTitle" placeholder="Meta Title"
                            value="<?= old('metaTitle', $product->metaTitle); ?>">
                    </div>
                </div>
            </div>
            
            <div class="row py-2">
                <!-- Meta Description -->
                <div class="col-sm-12 col-12">
                    <div class="mb-3">
                        <label class="form-label">Meta Description</label>
                        <textarea class="form-control" name="metaDescription" placeholder="Meta Description"><?= old('metaDescription', $product->metaDescription); ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="row py-2">
                 <!-- Meta Keywords -->
                <div class="col-sm-12 col-12">
                    <div class="mb-3">
                        <label class="form-label">Meta Keywords</label>
                        <textarea class="form-control" name="metaKeywords" placeholder="Meta Keywords"><?= old('metaKeywords', $product->metaKeywords); ?></textarea>
                    </div>
                </div>
            </div>


            <div class="row py-2">
                
                <!-- Status -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">Status<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="statusActive" value="Active" <?= old('status', $product->status) === 'Active' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusActive">Active</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="statusInactive" value="Block" <?= old('status', $product->status) === 'Block' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">Inactive</label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Can Purchasable -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">Can Purchasable<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="canPurchasable" id="statusActive" value="Yes" <?= old('canPurchasable', $product->canPurchasable) === 'Yes' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusActive">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="canPurchasable" id="statusInactive" value="No" <?= old('canPurchasable', $product->canPurchasable) === 'No' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Show Stock Out -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">Show Stock Out<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="stockStatus" id="statusActive" value="Enable" <?= old('stockStatus',$product->stockStatus) === 'Enable' ? 'checked' : '' ?> >
                                <label class="form-check-label" for="statusActive">Enable</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="stockStatus" id="statusInactive" value="Disable" <?= old('stockStatus', $product->stockStatus) === 'Disable' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">Disable</label>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            
            <div class="row py-2">
                
                <!-- Refundable  -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">Refundable<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="refundable" id="statusActive" value="Yes" <?= old('refundable', $product->refundable) === 'Yes' ? 'checked' : '' ?> >
                                <label class="form-check-label" for="statusActive">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="refundable" id="statusInactive" value="No" <?= old('refundable', $product->refundable) === 'No' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- COD  -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">COD<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="cod" id="statusActive" value="Yes" <?= old('cod',$product->cod) === 'Yes' ? 'checked' : '' ?> >
                                <label class="form-check-label" for="statusActive">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="cod" id="statusInactive" value="No" <?= old('cod',$product->cod) === 'No' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                
                
               
                
                <!-- Trending  -->
                <div class="col-sm-4 col-12">
                    <div class="mb-3">
                        <label class="form-label">Trending<span class="text-danger ms-1">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="trending" id="statusActive" value="Yes" <?= old('trending',$product->trending) === 'Yes' ? 'checked' : '' ?> >
                                <label class="form-check-label" for="statusActive">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="trending" id="statusInactive" value="No" <?= old('trending',$product->trending) === 'No' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="statusInactive">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
              
            <!-- Upload Product Image -->    
            <div class="row py-2">
                    <!-- Main Image Upload -->
                     <div class="col-md-12">
                         <label class="form-label" for="summernote">Product Image</label>
                        <div class="profile-pic-upload">
                            <div class="profile-pic">
                                <span>
                                    <i class="ti ti-circle-plus mb-1 fs-16"></i> Product Image
                                </span>
                            </div>
                            <div class="new-employee-field">
                                <div class="mb-0">
                                    <div class="image-upload mb-0">
                                        <input type="file" name="productImage[]" multiple>
                                        <div class="image-uploads">
                                            <h4>Upload Image</h4>
                                        </div>
                                    </div>
                                    <span class="fs-13 fw-medium mt-2">
                                        Upload an image below 1 MB, Accepted File format JPG, PNG, JPEG, Accepted size
                                        800*800px
                                    </span>
                                    <!-- Show custom image error -->
                                    <?php if(session()->getFlashdata('error')): ?>
                                        <p class="text-danger"><?= session()->getFlashdata('error') ?></p>
                                    <?php endif; ?>
                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            
            <!-- Similar update logic continues for price, gst, stock, meta fields, descriptions, image display etc. -->
            <!-- Show existing images -->
            <div class="row">
                <?php foreach($images as $img): ?>
                    <div class="col-2">
                        <img src="<?= base_url('assets/admin/vijayaagni/products/'.$img->name) ?>" width="100px !important; height:100px !important">
                        <button type="button" class="btn btn-danger btn-sm remove-image" data-image="<?= $img->name ?>">Remove</button>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="text-end">
                <button type="submit" class="btn btn-primary">Update Product</button>
            </div>
        </form>
    </div>
</div>


    
<script>
$(document).on('click', '.remove-image', function() {
    const imageName = $(this).data('image');
    const productId = "<?= $product->id ?>";
    $.post("<?= base_url('admin/product/removeProductImage') ?>", {image: imageName, productId: productId}, function(response) {
        if(response.status === 'success') location.reload();
    }, 'json');
});
</script>



<!-- Fetch Child Category -->


<!-- Initialize Summernote -->
<script>
$(document).ready(function() {
    $('#longDescription').summernote({
        height: 400 // set editor height
    });
});
</script>




<?= $this->endSection(); ?>