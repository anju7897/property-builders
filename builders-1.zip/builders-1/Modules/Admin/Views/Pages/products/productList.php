<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold"><?= $pageTitle ?></h4>
			
		</div>
	</div>
	<ul class="table-top-head">
		
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url("admin/product/add-product") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Add Product
		</a>
	</div>
</div>

<!-- Category List Card -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
        <h5 class="card-title mb-0">Product List</h5>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table id="productList" class="table table-bordered table-striped table-hover datatable nowrap w-100">
                <thead>
                    <tr>
                        <th>S.N.</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Child Category</th>
                        <th>Brand</th>
                        <th>Selling Price</th>
                        <th>Status</th>
                        <th>Trending</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<script>
    var getProductListUrl = "<?= base_url('admin/product/get-product-list'); ?>";
</script>

<?= $this->endSection() ?>
<?= $this->section("js") ?>
<script src="<?= base_url('assets/admin/custom/js/product/productList.js');?>"></script>  <!-- Include js file -->
<?= $this->endSection() ?>