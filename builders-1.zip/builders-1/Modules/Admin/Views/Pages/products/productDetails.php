<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold">
				<?= $pageTitle ?>
			</h4>

		</div>
	</div>
	<ul class="table-top-head">

		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
					class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url(" admin/product/product-list") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Product List
		</a>
	</div>
</div>

<!-- Product Details -->
<div class="card">
    <div class="card-body">
        <div class="row">

            <!-- Product Information (Full Width) -->
            <div class="col-md-12 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Product:</strong> <?= esc($product->name) ?></p>
                                <p><strong>SKU:</strong> <?= esc($product->sku) ?></p>
                                <p><strong>Category:</strong> <?= esc($product->categoryName) ?></p>
                                <p><strong>Sub Category:</strong> <?= esc($product->childCategoryName) ?></p>
                                <p><strong>Brand:</strong> <?= esc($product->brandName) ?></p>
                                <p><strong>Selling Price:</strong> ₹<?= number_format($product->sellingPrice, 2) ?></p>
                                <p><strong>Buying Price:</strong> ₹<?= number_format($product->buyingPrice, 2) ?></p>
                                <p><strong>GST:</strong> <?= esc($product->gstName) ?>%</p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Status:</strong> <?= esc($product->status) ?></p>
                                <p><strong>Trending:</strong> <?= esc($product->trending) ?></p>
                                <p><strong>Can Purchasable:</strong> <?= esc($product->canPurchasable) ?></p>
                                <p><strong>Refundable:</strong> <?= esc($product->refundable) ?></p>
                                <p><strong>COD:</strong> <?= esc($product->cod) ?></p>
                                <p><strong>Weight:</strong> <?= esc($product->weight) ?> KG</p>
                                <p><strong>Dimensions (LxWxH):</strong> <?= esc($product->length) ?> x <?= esc($product->width) ?> x <?= esc($product->height) ?> cm</p>
                            </div>
                        </div>

                        <h4 class="mt-4">Descriptions</h4>
                        <div class="mb-3">
                            <strong>Short Description:</strong>
                            <div class="border p-2 rounded bg-light">
                                <?= htmlspecialchars_decode($product->shortDescription) ?>
                            </div>
                        </div>
                        <div>
                            <strong>Long Description:</strong>
                            <div class="border p-2 rounded bg-light">
                                <?= htmlspecialchars_decode($product->longDescription) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Product Images (Full Width Below Info) -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="mb-3">Product Images</h4>
                        <div class="row">
                            <?php if (!empty($images)) : ?>
                                <?php foreach ($images as $img) : ?>
                                    <div class="col-md-3 col-sm-12 col-12 mb-3 text-center" >
                                        <img src="<?= base_url('assets/admin/vijayaagni/products/' . $img->name) ?>" alt="Product Image" class="img-thumbnail" style="max-height:120px; max-width:150px">
                                        <!--<p class="small mt-1"><?= esc($img->name) ?></p>-->
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div class="col-12">
                                    <p>No Images Available</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>



<?= $this->endSection() ?>