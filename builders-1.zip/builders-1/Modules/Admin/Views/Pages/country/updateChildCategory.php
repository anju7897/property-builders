 <?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold"><?= $pageTitle ?></h4>
			
		</div>
	</div>
	<ul class="table-top-head">
		
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url("admin/category/add-category") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Add Category
		</a>
	</div>
</div>



<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Child Category Details</h4>
    </div>
    <div class="card-body">
       <form action="<?= base_url('admin/category/update-child-category/' . $childCategory->id) ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
        
            <div class="form-group">
                <label>Name<span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= old('name', $childCategory->name) ?>" required>
            </div>
        
            <div class="form-group">
                <label>Slug<span class="text-danger">*</span></label>
                <input type="text" name="slug" class="form-control" value="<?= old('slug', $childCategory->slug) ?>" required>
            </div>
        
            <div class="form-group">
                <label>Status<span class="text-danger">*</span></label>
                <select name="status" class="form-control" required>
                    <option value="Active" <?= ($childCategory->status == 'Active') ? 'selected' : '' ?>>Active</option>
                    <option value="Block" <?= ($childCategory->status == 'Block') ? 'selected' : '' ?>>Block</option>
                </select>
            </div>
        
            <div class="form-group">
                <label>Is Trending?<span class="text-danger">*</span></label>
                <select name="isTrending" class="form-control" required>
                    <option value="Yes" <?= ($childCategory->isTrending == 'Yes') ? 'selected' : '' ?>>Yes</option>
                    <option value="No" <?= ($childCategory->isTrending == 'No') ? 'selected' : '' ?>>No</option>
                </select>
            </div>
        
            <div class="form-group">
                <label>Image</label><br>
                <?php if (!empty($childCategory->image)): ?>
                    <img src="<?= base_url('assets/admin/vijayaagni/category/' . $childCategory->image) ?>" width="100">
                <?php endif; ?>
                <input type="file" name="image" class="form-control mt-2">
                <small class="text-muted">Leave blank to keep existing image. (Max 1MB, 512x512)</small>
            </div>
        
            <button type="submit" class="btn btn-primary">Update Category</button>
        </form>

    </div>
</div>













<?= $this->endSection(); ?>