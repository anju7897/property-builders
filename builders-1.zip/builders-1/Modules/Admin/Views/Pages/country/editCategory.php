<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<!-- Breadcrumbs -   START -->

<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?= $pageTitle ?></h4>

        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
        </li>
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                    class="ti ti-chevron-up"></i></a>
        </li>
    </ul>
    <div class="page-btn mt-0">
        <a href="<?= base_url("admin/category/category-list") ?>" class="btn btn-secondary">
            <i data-feather="arrow-left" class="me-2"></i>Back to Category List
        </a>
    </div>
</div>

<!-- Breadcrumbs -   END -->




<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">
            Category Details
        </h4>
    </div>
   <?php 
    $category = $getSingleCategoryRecord ?? [];
?>
<div class="card-body">
    <form action="<?= base_url('admin/category/update-category/' . $category->id); ?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <!-- Name -->
            <div class="col-sm-6 col-12">
                <div class="mb-3">
                    <label class="form-label">Primary Category<span class="text-danger ms-1">*</span></label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name"
                        value="<?= old('name', $category->name); ?>" minlength="1" maxlength="90">
                    <p class="text-danger"><?= session("errors.name") ?></p>
                </div>
            </div>

            <!-- Slug -->
            <div class="col-sm-6 col-12">
                <div class="mb-3">
                    <label class="form-label">Slug <span class="text-danger ms-1">*</span></label>
                    <input type="text" class="form-control" name="slug" placeholder="Enter Slug"
                        value="<?= old('slug', $category->slug); ?>" minlength="1" maxlength="255">
                    <p class="text-danger"><?= session("errors.slug") ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Trending -->
            <div class="col-sm-6 col-12">
                <div class="mb-3">
                    <label class="form-label">Trending<span class="text-danger ms-1">*</span></label>
                    <select class="form-control" name="isTrending">
                        <option value="Yes" <?= old('isTrending', $category->isTrending) === 'Yes' ? 'selected' : '' ?>>Yes</option>
                        <option value="No" <?= old('isTrending', $category->isTrending) === 'No' ? 'selected' : '' ?>>No</option>
                    </select>
                    <p class="text-danger"><?= session("errors.isTrending") ?></p>
                </div>
            </div>

            <!-- Status -->
            <div class="col-sm-6 col-12">
                <div class="mb-3">
                    <label class="form-label">Status<span class="text-danger ms-1">*</span></label>
                    <select class="form-control" name="status">
                        <option value="Active" <?= old('status', $category->status) === 'Active' ? 'selected' : '' ?>>Active</option>
                        <option value="Block" <?= old('status', $category->status) === 'Block' ? 'selected' : '' ?>>Block</option>
                    </select>
                    <p class="text-danger"><?= session("errors.status") ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Image -->
            <div class="col-md-12">
                <div class="profile-pic-upload">
                    <div class="profile-pic">
                        <!-- Existing Image Preview -->
                        <?php if (!empty($category->image)){ ?>
                            <div class="mt-2">
                                <img src="<?= base_url('assets/admin/vijayaagni/category/' . $category->image); ?>" alt="Current Image" width="100">
                            </div>
                        <?php } else { ?>
                        <span><i class="ti ti-circle-plus mb-1 fs-16"></i> Category Image</span>
                        <?php  } ?>
                    </div>
                    <div class="new-employee-field">
                        <div class="mb-0">
                            <div class="image-upload mb-0">
                                <input type="file" name="image">
                                <div class="image-uploads">
                                    <h4>Upload Image</h4>
                                </div>
                            </div>
                            <span class="fs-13 fw-medium mt-2">
                                Upload an image below 1 MB, Accepted File format JPG, PNG, JPEG, Accepted size 512*512px
                            </span>
                            <!-- Show custom image error -->
                            <?php if(session()->getFlashdata('error')): ?>
                                <p class="text-danger"><?= session()->getFlashdata('error') ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Submit Buttons -->
        <div class="text-end settings-bottom-btn mt-0">
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
    </form>
</div>

</div>



<?= $this->endSection(); ?>