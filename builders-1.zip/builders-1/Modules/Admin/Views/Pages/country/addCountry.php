<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<!-- Breadcrumbs -   START -->

<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?= $pageTitle ?></h4>

        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
        </li>
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                    class="ti ti-chevron-up"></i></a>
        </li>
    </ul>
    <div class="page-btn mt-0">
        <a href="<?= base_url("admin/country/country-list") ?>" class="btn btn-secondary">
            <i data-feather="arrow-left" class="me-2"></i>Back to Country List
        </a>
    </div>
</div>

<!-- Breadcrumbs -   END -->




<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">
            Country
        </h4>
    </div>
    <div class="card-body">
        <form action="<?= base_url('admin/country/add-country'); ?>" method="post" enctype="multipart/form-data">

            <div class="row">

                <!-- Name -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Country Image<span class="text-danger ms-1">*</span></label>
                        <input type="file" class="form-control" name="countryImage"
                            value="<?= old('countryImage'); ?>" minlength="1" maxlength="90" data-bs-toggle="tooltip"
                            data-bs-placement="top" title="Enter 1 to 90 characters">
                        <p class="text-danger"><?= session("errors.countryImage") ?></p>
                    </div>
                </div>

                <!-- Slug -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Country Name <span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="countryName" placeholder="Enter Country Name"
                            value="<?= old('countryName'); ?>" minlength="1" maxlength="255" data-bs-toggle="tooltip"
                            data-bs-placement="top" title="Enter 2 to 255 characters">
                        <p class="text-danger"><?= session("errors.countryName") ?></p>
                    </div>
                </div>


            </div>

            <div class="row">

               

                <!-- Status -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Status<span class="text-danger ms-1">*</span></label>
                        <select class="form-control" name="status">
                            <option value="Active" <?= old('status') === 'Active' ? 'selected' : '' ?>>Active</option>
                            <option value="Block" <?= old('status') === 'Block' ? 'selected' : '' ?>>Block</option>
                        </select>
                        <p class="text-danger"><?= session("errors.status") ?></p>
                    </div>
                </div>


            </div>

        </div>


    



            <!-- Submit Buttons -->
            <div class="text-end settings-bottom-btn mt-0">
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>

    </div>
</div>



<?= $this->endSection(); ?>