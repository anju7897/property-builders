<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold"><?= $pageTitle ?></h4>
			<h6><?= $pageName ?></h6>
		</div>
	</div>
	<ul class="table-top-head">
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
		</li>
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url("admin/profile-list") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Profile List
		</a>
	</div>
</div>


<div class="card flex-fill mb-0">
	<div class="card-header">
		<h4 class="fs-18 fw-bold">Profile</h4>
	</div>
	<div class="card-body">
	   
		<form action="<?= base_url('admin/profile'); ?>" method="post" enctype="multipart/form-data">
    <!-- Basic Info -->
    <div class="card-title-head">
        <h6 class="fs-16 fw-bold mb-3">
            <span class="fs-16 me-2"><i class="ti ti-user"></i></span>
            Basic Information
        </h6>
    </div>
    <div class="row mb-3">
        <!-- Logo -->
        <div class="col-md-6">
            <div class="profile-pic-upload">
                <div class="profile-pic">
                    <span>
                        <?php if (!empty($getProfileRecord->logo)): ?>
                            <img src="<?= base_url("assets/admin/vijayaagni/logo/" . $getProfileRecord->logo) ?>" width="80" height="50">
                        <?php else: ?>
                            <i class="ti ti-circle-plus mb-1 fs-16"></i> Add Logo
                        <?php endif; ?>
                    </span>
                </div>
                <div class="new-employee-field">
                    <div class="mb-0">
                        <div class="image-upload mb-0">
                            <input type="file" name="logo">
                            <div class="image-uploads">
                                <h4>Upload Logo</h4>
                            </div>
                        </div>
                        <span class="fs-13 fw-medium mt-2">
                            Upload an image below 2 MB, Accepted File format JPG, PNG
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <!-- Favicon -->
        <div class="col-md-6">
            <div class="profile-pic-upload">
                <div class="profile-pic">
                    <span>
                        <?php if (!empty($getProfileRecord->favIcon)): ?>
                            <img src="<?= base_url("assets/admin/vijayaagni/logo/" . $getProfileRecord->favIcon) ?>" width="80" height="50">
                        <?php else: ?>
                            <i class="ti ti-circle-plus mb-1 fs-16"></i> Add Favicon
                        <?php endif; ?>
                    </span>
                </div>
                <div class="new-employee-field">
                    <div class="mb-0">
                        <div class="image-upload mb-0">
                            <input type="file" name="favIcon">
                            <div class="image-uploads">
                                <h4>Upload Favicon</h4>
                            </div>
                        </div>
                        <span class="fs-13 fw-medium mt-2">
                            Upload an image below 2 MB, Accepted File format JPG, PNG
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Info -->
    <div class="row">
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Full Name<span class="text-danger ms-1">*</span></label>
                <input type="text" class="form-control" name="name" placeholder="Enter Full Name" value="<?= esc($getProfileRecord->name) ?>" minlength="2" maxlength="45" data-bs-toggle="tooltip" data-bs-placement="top" title="Enter 2 to 45 characters">
                <p class="text-danger"><?= session("errors.name") ?></p>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Email<span class="text-danger ms-1">*</span></label>
                <input type="email" class="form-control" name="emailId" placeholder="Enter Email" value="<?= esc($getProfileRecord->emailId) ?>" minlength="2" maxlength="45" data-bs-toggle="tooltip" data-bs-placement="top" title="Enter 2 to 45 characters">
                <p class="text-danger"><?= session("errors.emailId") ?></p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Phone<span class="text-danger ms-1">*</span></label>
                <input type="number" class="form-control" name="phoneNo" placeholder="Enter Phone No." value="<?= esc($getProfileRecord->phoneNo) ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Enter 2 to 50 characters">
                <p class="text-danger"><?= session("errors.phoneNo") ?></p>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Company Name</label>
                <input type="text" class="form-control" name="companyName" placeholder="Enter Company Name" value="<?= esc($getProfileRecord->companyName) ?>" minlength="2" maxlength="50" data-bs-toggle="tooltip" data-bs-placement="top" title="Enter 2 to 50 characters">
                <p class="text-danger"><?= session("errors.companyName") ?></p>
            </div>
        </div>
    </div>

    <!-- DOB & Gender -->
    <div class="row">
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Date Of Birth<span class="text-danger ms-1">*</span></label>
                <input type="date" class="form-control" name="dob" value="<?= esc($getProfileRecord->dob) ?>">
                <p class="text-danger"><?= session("errors.dob") ?></p>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Gender</label>
                <select class="form-control" name="gender">
                    <option value="Female" <?= $getProfileRecord->gender == "Female" ? "selected" : "" ?>>Female</option>
                    <option value="Male" <?= $getProfileRecord->gender == "Male" ? "selected" : "" ?>>Male</option>
                    <option value="Other" <?= $getProfileRecord->gender == "Other" ? "selected" : "" ?>>Other</option>
                </select>
                <p class="text-danger"><?= session("errors.gender") ?></p>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select class="form-control" name="status">
                    <option value="Active" <?= $getProfileRecord->status == "Active" ? "selected" : "" ?>>Active</option>
                    <option value="Block" <?= $getProfileRecord->status == "Block" ? "selected" : "" ?>>Block</option>
                </select>
                <p class="text-danger"><?= session("errors.status") ?></p>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="mb-3">
                <label class="form-label">GST<span class="text-danger ms-1">*</span></label>
                <input type="text" class="form-control" name="gst" value="<?= esc($getProfileRecord->gst) ?>">
                <p class="text-danger"><?= session("errors.gst") ?></p>
            </div>
        </div>
    </div>

    <!-- Address Info -->
    <div class="card-title-head pt-2">
        <h6 class="fs-16 fw-bold mb-3">
            <span class="fs-16 me-2"><i class="ti ti-map-pin"></i></span>
            Address Information
        </h6>
    </div><hr>
    <div class="row">
        <div class="col-md-12">
            <div class="mb-3">
                <label class="form-label">Address <span class="text-danger">*</span></label>
                <input type="text" value="<?= esc($getProfileRecord->address) ?>" name="address" class="form-control">
                <p class="text-danger"><?= session("errors.address") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Country <span class="text-danger">*</span></label>
                <input type="text" name="country" value="<?= esc($getProfileRecord->country) ?>" class="form-control">
                <p class="text-danger"><?= session("errors.country") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">State <span class="text-danger">*</span></label>
                <input type="text" name="state" value="<?= esc($getProfileRecord->state) ?>" class="form-control">
                <p class="text-danger"><?= session("errors.state") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">City <span class="text-danger">*</span></label>
                <input type="text" name="city" value="<?= esc($getProfileRecord->city) ?>" class="form-control">
                <p class="text-danger"><?= session("errors.city") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Postal Code <span class="text-danger">*</span></label>
                <input type="number" name="pinCode" value="<?= esc($getProfileRecord->pinCode) ?>" class="form-control">
                <p class="text-danger"><?= session("errors.pinCode") ?></p>
            </div>
        </div>
    </div>

    <!-- Bank Info -->
    <div class="card-title-head pt-3">
        <h6 class="fs-16 fw-bold mb-3">
            <span class="fs-16 me-2"><i class="ti ti-building-bank"></i></span>
            Bank Information
        </h6>
    </div><hr>
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Bank Name <span class="text-danger"></span></label>
                <input type="text" class="form-control" name="bankName" value="<?= esc($getProfileRecord->bankName) ?>">
                <p class="text-danger"><?= session("errors.bankName") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Account Holder Name <span class="text-danger"></span></label>
                <input type="text" class="form-control" name="accountHolder" value="<?= esc($getProfileRecord->accountHolder) ?>">
                <p class="text-danger"><?= session("errors.accountHolder") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Account Number <span class="text-danger"></span></label>
                <input type="text" class="form-control" name="accountNumber" value="<?= esc($getProfileRecord->accountNumber) ?>">
                <p class="text-danger"><?= session("errors.accountNumber") ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">IFSC Code <span class="text-danger"></span></label>
                <input type="text" class="form-control" name="ifscCode" value="<?= esc($getProfileRecord->ifscCode) ?>">
                <p class="text-danger"><?= session("errors.ifscCode") ?></p>
            </div>
        </div>
    </div>

    <!-- Submit Button -->
    <div class="text-end">
        <button type="submit" class="btn btn-primary">Update Profile</button>
    </div>
</form>

	</div>
</div>
 <!--JavaScript for Real-time Error Removal -->
<script>
    document.querySelectorAll('.form-control').forEach(function (input) {
        input.addEventListener('input', function () {
            if (this.classList.contains('is-invalid')) {
                this.classList.remove('is-invalid');
                const feedback = this.nextElementSibling;
                if (feedback && feedback.classList.contains('invalid-feedback')) {
                    feedback.remove();
                }
            }
        });
    });
</script>
<?= $this->endSection() ?>
