<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="">
    <meta name="keywords"
        content="">
    <meta name="author" content="">
    <meta name="robots" content="index, follow">
    <title>Vijayaagn Admin</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/admin/img/favicon.png'); ?>">

    <!-- Apple Touch Icon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/admin/img/apple-touch-icon.png'); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/css/bootstrap.min.css'); ?>">

    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/plugins/fontawesome/css/fontawesome.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/admin/plugins/fontawesome/css/all.min.css'); ?>">

    <!-- Tabler Icon CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/plugins/tabler-icons/tabler-icons.css'); ?>">

    <!-- Main CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/css/style.css'); ?>">

</head>

<body class="account-page bg-white">

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>
    <!-- <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div> -->

    <!-- Main Wrapper -->
    <div class="main-wrapper">
        <div class="account-content">
            <div class="login-wrapper login-new">
                <div class="row w-100">
                    <div class="col-lg-5 mx-auto">
                        <div class="login-content user-login">
                            <div class="login-logo">
                                <img src="<?= base_url('') ?>assets/frontend/images/banner/logo-pair.png" alt="img">
                                <a href="#" class="login-logo logo-white">
                                    <img src="<?= base_url('') ?>assets/frontend/images/banner/logo-pair.png" alt="Img">
                                </a>
                            </div>
                            <form id="loginForm" action="<?= base_url('admin/login'); ?>" method="post">
                                <div class="card">
                                    <div class="card-body p-5">
                                        <div class="login-userheading">
                                            <center><h3>Admin Login</h3></center>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email <span class="text-danger"> *</span></label>
                                            <div class="input-group">
                                                <input type="text" value="<?= old('emailId') ?>" name="emailId" class="form-control border-end-0">
                                                <span class="input-group-text border-start-0">
                                                    <i class="ti ti-mail"></i>
                                                </span>
                                            </div>
                                            <?php if (isset($validation) && $validation->hasError('emailId')): ?>
                                    <div class="text-danger mt-1"><?= $validation->getError('emailId'); ?></div>
                                <?php endif; ?>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Password <span class="text-danger">
                                                    *</span></label>
                                            <div class="pass-group">
                                                <input type="password" value="<?= old('emailId') ?>" name="password" class="pass-input form-control">
                                                <span class="ti toggle-password ti-eye-off text-gray-9"></span>
                                            </div>
                                            <?php if (isset($validation) && $validation->hasError('password')): ?>
                                    <div class="text-danger mt-1"><?= $validation->getError('password'); ?></div>
                                <?php endif; ?>
                                        </div>
                                        <div class="form-login authentication-check">
                                            <div class="row">
                                                <div class="col-12 d-flex align-items-center justify-content-between">
                                                    <div class="custom-control custom-checkbox">
                                                    
                                                    <!-- reCAPTCHA integration here -->
                                                        <div class="mb-3">
                                                            <div class="g-recaptcha" data-sitekey="6LdpCGorAAAAALFqtTSHr88WfP64EUlt8lkvF3vc"></div>
                                                            <?php if (session()->getFlashdata('captcha_error')): ?>
                                                                <div class="text-danger mt-2"><?= session()->getFlashdata('captcha_error') ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                        </div>
                                                    <div class="text-end">
                                                        <a class="text-orange fs-16 fw-medium"
                                                            href="forgot-password.html">Forgot Password?</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-login">
                                            <button type="submit" class="btn btn-primary w-100">Login</button>
                                        </div>
                                                                       
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="my-4 d-flex justify-content-center align-items-center copyright-text">
                            <p>Copyright &copy; <?= date('Y') ?> vijayaagni.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Main Wrapper -->
     

    <!-- jQuery -->
    <script src="<?= base_url('assets/admin/js/jquery-3.7.1.min.js'); ?>"
        type="fd4db5cb593f2a4b14f9a6e1-text/javascript"></script>

    <!-- Feather Icon JS -->
    <script src="<?= base_url('assets/admin/js/feather.min.js'); ?>" type="fd4db5cb593f2a4b14f9a6e1-text/javascript">
    </script>

    <!-- Bootstrap Core JS -->
    <script src="<?= base_url('assets/admin/js/bootstrap.bundle.min.js'); ?>"
        type="fd4db5cb593f2a4b14f9a6e1-text/javascript"></script>

    <!-- Custom JS -->
    <script src="<?= base_url('assets/admin/js/script.js'); ?>" type="fd4db5cb593f2a4b14f9a6e1-text/javascript">
    </script>

    <script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js"
        data-cf-settings="fd4db5cb593f2a4b14f9a6e1-|49" defer></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"rayId":"9224283c18525517","version":"2025.1.0","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"3ca157e612a14eccbb30cf6db6691c29","b":1}'
        crossorigin="anonymous"></script>


        <!-- Include Google reCAPTCHA JS -->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<!-- jS to prevent form submit if captcha not clicked -->
<script>
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        var response = grecaptcha.getResponse();
        if (response.length === 0) {
            e.preventDefault();
            alert('Please verify you are not a robot.');
        }
    });
</script>
</body>

</html>