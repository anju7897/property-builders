<?= $this->extend('Modules\Admin\Views\Layouts\MasterLayouts'); ?>
<?= $this->section('content'); ?>

	<div class="row">
				
					<div class="col-xl-3 col-sm-6 col-12 d-flex">
						<div class="dash-count bg-primary">
							<div class="dash-counts">
								<h4 class="mb-1">100</h4>
								<p class="text-white mb-0">Customers</p>
							</div>
							<div class="dash-imgs">
								<i data-feather="user"></i>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12 d-flex">
						<div class="dash-count das1 bg-cyan-900">
							<div class="dash-counts">
								<h4 class="mb-1">110</h4>
								<p class="text-white mb-0">Suppliers</p>
							</div>
							<div class="dash-imgs">
								<i data-feather="user-check"></i>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12 d-flex">
						<div class="dash-count das2 bg-dark">
							<div class="dash-counts">
								<h4 class="mb-1">150</h4>
								<p class="text-white mb-0">Purchase Invoice</p>
							</div>
							<div class="dash-imgs">
								<img src="<?= base_url('assets/admin')?>/img/icons/file-text-icon-01.svg" class="img-fluid" alt="icon">
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12 d-flex">
						<div class="dash-count das3 bg-success">
							<div class="dash-counts">
								<h4 class="mb-1">170</h4>
								<p class="text-white mb-0">Sales Invoice</p>
							</div>
							<div class="dash-imgs">
								<i data-feather="file"></i>
							</div>
						</div>
					</div>
				</div>
				<!-- Button trigger modal -->

			
<?= $this->endSection() ?>