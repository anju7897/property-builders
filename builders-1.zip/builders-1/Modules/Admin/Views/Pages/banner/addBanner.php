<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<style>
.longDescription .note-editable {
    min-height: 390px !important;
}
</style>

<!-- Breadcrumbs -   START -->
<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?= $pageTitle ?></h4>

        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
        </li>
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                    class="ti ti-chevron-up"></i></a>
        </li>
    </ul>
    <div class="page-btn mt-0">
        <a href="<?= base_url("admin/category/category-list") ?>" class="btn btn-secondary">
            <i data-feather="arrow-left" class="me-2"></i>Back to Category List
        </a>
    </div>
</div>

<!-- Breadcrumbs -   END -->

<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">
            Banner
        </h4>
    </div>
    <div class="card-body">
        <form action="<?= base_url('admin/banner/add-banner'); ?>" method="post" enctype="multipart/form-data">

            <div class="row">
                <!-- Product Name -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Banner Image<span class="text-danger ms-1">*</span></label>
                        <input type="file" class="form-control" name="bannerImage" placeholder="Upload Images"
                            value="<?= old('bannerImage'); ?>">
                        <p class="text-danger"><?= session("errors.bannerImage") ?></p>
                    </div>
                </div>

                <!-- Slug -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Button Text 1<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="buttonTextOne" placeholder="Enter Text"
                            value="<?= old('buttonTextOne'); ?>">
                        <p class="text-danger"><?= session("errors.buttonTextOne") ?></p>
                    </div>
                </div>
            </div>

            <div class="row py-2">
               <!-- SKU -->
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Button Link 1<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="buttonLinkOne" placeholder="Enter Link"
                            value="<?= old('buttonLinkOne'); ?>">
                        <p class="text-danger"><?= session("errors.buttonLinkOne") ?></p>
                    </div>
                </div>
                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Button Text 2<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="buttonTextTwo" placeholder="Enter Text"
                            value="<?= old('buttonTextTwo'); ?>">
                        <p class="text-danger"><?= session("errors.buttonTextTwo") ?></p>
                    </div>
                </div>

                <div class="col-sm-6 col-12">
                    <div class="mb-3">
                        <label class="form-label">Button Link 2<span class="text-danger ms-1">*</span></label>
                        <input type="text" class="form-control" name="buttonLinkTwo" placeholder="Enter Link"
                            value="<?= old('buttonLinkTwo'); ?>">
                        <p class="text-danger"><?= session("errors.buttonLinkTwo") ?></p>
                    </div>
                </div>


                
            </div>

        
            
            
           
            

            <!-- Submit Buttons -->
            <div class="text-end settings-bottom-btn mt-0">
                <button type="submit" class="btn btn-primary">Save Banner</button>
            </div>

        </form>
    </div>
</div>


<!-- Fetch Child Category -->
<script>
    $('#mainCategory').change(function(){
        var mainCatId = $(this).val();
        if(mainCatId != ''){
            $.ajax({
                url: "<?= base_url('admin/product/get-child-category') ?>",
                method: "POST",
                data: { parentId: mainCatId },
                success: function(response){
                    var data = JSON.parse(response);
                    var html = '<option value="">Select Child Category</option>';
                    if(data.length > 0){
                        for(var i=0; i<data.length; i++){
                            html += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
                        }
                    }
                    $('#childCategory').html(html);
                }
            });
        }else{
            $('#childCategory').html('<option value="">Select Child Category</option>');
        }
    });
</script>


<!-- Initialize Summernote -->
<script>
$(document).ready(function() {
    $('#longDescription').summernote({
        height: 400 // set editor height
    });
});
</script>




<?= $this->endSection(); ?>