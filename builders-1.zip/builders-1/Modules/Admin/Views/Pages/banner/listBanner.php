<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<style>
    .banner-table-container {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        border: 1px solid #dee2e6;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }

    .table th,
    .table td {
        vertical-align: middle;
        text-align: center;
        border: 1px solid #dee2e6;
    }

    .table thead {
        background-color: white;
        color: #ffffff;
    }

    .table tbody {
        background-color: white;
    }

    .table img {
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    .action-buttons .btn {
        margin: 2px;
    }

    h3 {
        font-weight: 600;
        margin-bottom: 20px;
    }
</style>

<div class="container mt-5 banner-table-container">
    <h3 class="">Banner List</h3>

    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <?php if (!empty($banners)) : ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Banner Image</th>
                        <th>Button Text 1</th>
                        <th>Button Link 1</th>
                        <th>Button Text 2</th>
                        <th>Button Link 2</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($banners as $index => $banner) : ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td>
                                <?php if (!empty($banner->bannerImage)) : ?>
                                    <img src="<?= base_url('assets/admin/auPair/images/banner/' . $banner->bannerImage) ?>" width="100">
                                <?php else : ?>
                                    <span class="text-muted">No Image</span>
                                <?php endif; ?>
                            </td>
                            <td><?= esc($banner->buttonTextOne) ?></td>
                            <td><a href="<?= esc($banner->buttonLinkOne) ?>" target="_blank"><?= esc($banner->buttonLinkOne) ?></a></td>
                            <td><?= esc($banner->buttonTextTwo) ?></td>
                            <td><a href="<?= esc($banner->buttonLinkTwo) ?>" target="_blank"><?= esc($banner->buttonLinkTwo) ?></a></td>
                            <td class="action-buttons">
                                <a href="<?= base_url('admin/banner/edit-banner/' . esc($banner->id)) ?>" class="btn btn-sm btn-warning">
    <i class="fas fa-edit"></i> Edit
</a>

                                <a href="<?= base_url('admin/banner/delete-banner/' . $banner->id) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete this banner?')">
                                    <i class="fas fa-trash-alt"></i> 
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else : ?>
        <div class="alert alert-info">No banners found.</div>
    <?php endif; ?>
</div>

<?= $this->endSection(); ?>
