<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold">
				<?= $pageTitle ?>
			</h4>

		</div>
	</div>
	<ul class="table-top-head">
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
		</li>
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
					class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url(" admin/profile-list") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Tags List
		</a>
	</div>
</div>




<div class="card flex-fill mb-0">
	<div class="card-header">
		<h4 class="fs-18 fw-bold">
			Tags Details
		</h4>
	</div>
	<div class="card-body">
		<form action="<?= base_url('admin/blog/add-blog-tags'); ?>" method="post">

			<div class="row">

				<!-- Name -->
				<div class="col-sm-6 col-12">
					<div class="mb-3">
						<label class="form-label">Tags Name <span class="text-danger ms-1">*</span></label>
						<input type="text" class="form-control" name="name" placeholder="Enter Name"
							value="<?= old('name'); ?>" minlength="1" maxlength="45" data-bs-toggle="tooltip"
							data-bs-placement="top" title="Enter name 1 to 45 characters">
						<p class="text-danger">
							<?= session("errors.name") ?>
						</p>
					</div>
				</div>

				<!-- Status -->
				<div class="col-sm-6 col-12">
					<div class="mb-3">
						<label class="form-label">Status<span class="text-danger ms-1">*</span></label>
						<select class="form-control" name="status">
							<option value="Active" <?=old('status')==='Active' ? 'selected' : '' ?>>Active</option>
							<option value="Block" <?=old('status')==='Block' ? 'selected' : '' ?>>Block</option>
						</select>
						<p class="text-danger">
							<?= session("errors.status") ?>
						</p>
					</div>
				</div>

			</div>

			<!-- Submit Buttons -->
			<div class="text-end settings-bottom-btn mt-0">
				<button type="submit" class="btn btn-primary">Save Changes</button>
			</div>
		</form>

	</div>
</div>

<?= $this->endSection(); ?>