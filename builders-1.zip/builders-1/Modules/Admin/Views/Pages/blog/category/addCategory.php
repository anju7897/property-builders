<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold"><?= $pageTitle ?></h4>
			
		</div>
	</div>
	<ul class="table-top-head">
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
		</li>
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url("admin/profile-list") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Category List
		</a>
	</div>
</div>




<div class="card flex-fill mb-0">
	<div class="card-header">
		<h4 class="fs-18 fw-bold">
		    Category Details
		 </h4>
	</div>
	<div class="card-body">
		<form action="<?= base_url('admin/blog/add-blog-category'); ?>" method="post" enctype="multipart/form-data">		

	<div class="row">
	    
		<!-- Name -->
		<div class="col-sm-6 col-12">
			<div class="mb-3">
				<label class="form-label">Category Name <span class="text-danger ms-1">*</span></label>
				<input type="text" class="form-control" name="name" placeholder="Enter Name"
					value="<?= old('name'); ?>" minlength="2" maxlength="45"
					data-bs-toggle="tooltip" data-bs-placement="top"
					title="Enter 2 to 45 characters">
				<p class="text-danger"><?= session("errors.name") ?></p>
			</div>
		</div>

		<!-- Slug -->
		<div class="col-sm-6 col-12">
			<div class="mb-3">
				<label class="form-label">Slug <span class="text-danger ms-1">*</span></label>
				<input type="text" class="form-control" name="slug" placeholder="Enter Slug"
					value="<?= old('slug'); ?>" minlength="2" maxlength="255"
					data-bs-toggle="tooltip" data-bs-placement="top"
					title="Enter 2 to 255 characters">
				<p class="text-danger"><?= session("errors.slug") ?></p>
			</div>
		</div>
		
		
	</div>
	
	<div class="row">
	    
		<!-- Trending -->
		<div class="col-sm-6 col-12">
			<div class="mb-3">
				<label class="form-label">Trending<span class="text-danger ms-1">*</span></label>
				<select class="form-control" name="isFeatured">
					<option value="Yes" <?= old('isFeatured') === 'Yes' ? 'selected' : '' ?>>Yes</option>
					<option value="No" <?= old('isFeatured') === 'No' ? 'selected' : '' ?>>No</option>
				</select>
				<p class="text-danger"><?= session("errors.isFeatured") ?></p>
			</div>
		</div>

		<!-- Status -->
		<div class="col-sm-6 col-12">
			<div class="mb-3">
				<label class="form-label">Status<span class="text-danger ms-1">*</span></label>
				<select class="form-control" name="status">
					<option value="Active" <?= old('status') === 'Active' ? 'selected' : '' ?>>Active</option>
					<option value="Block" <?= old('status') === 'Block' ? 'selected' : '' ?>>Block</option>
				</select>
				<p class="text-danger"><?= session("errors.status") ?></p>
			</div>
		</div>
		
		
	</div>
	
	<div class="row">
	    
		<!-- Priority Order -->
		<div class="col-sm-6 col-12">
			<div class="mb-3">
				<label class="form-label">Priority Order <span class="text-danger ms-1">*</span></label>
				<input type="text" class="form-control" name="priorityOrder" placeholder="Enter Number"
					value="<?= old('priorityOrder', '0'); ?>" minlength="1" maxlength="999"
					data-bs-toggle="tooltip" data-bs-placement="top"
					title="Enter 1 to 999 characters">
				<p class="text-danger"><?= session("errors.priorityOrder") ?></p>
			</div>
		</div>

		 <!-- Logo -->
        <div class="col-md-6">
            <div class="profile-pic-upload">
                <div class="profile-pic">
                    <span>
                        <?php if (!empty($getProfileRecord->categoryImage)): ?>
                            <img src="<?= base_url("assets/admin/vijayaagni/logo/" . $getProfileRecord->categoryImage) ?>" width="80" height="50">
                        <?php else: ?>
                            <i class="ti ti-circle-plus mb-1 fs-16"></i> Add Image
                        <?php endif; ?>
                    </span>
                </div>
                <div class="new-employee-field">
                    <div class="mb-0">
                        <div class="image-upload mb-0">
                            <input type="file" name="categoryImage">
                            <div class="image-uploads">
                                <h4>Upload Image</h4>
                            </div>
                        </div>
                        <span class="fs-13 fw-medium mt-2">
                            Upload an image below 1 MB, Accepted File format JPG, PNG, JPEG, Accepted size 512*512px
                        </span>
                        <p class="text-danger"><?= session("errors.categoryImage") ?></p>
                    </div>
                </div>
            </div>
        </div>
		
		
	</div>
	
    <div class="card-header">
		<h4 class="fs-18 fw-bold">
		    SEO Details
		 </h4>
	</div>

	<div class="row py-3">
		
        <!-- Meta Title -->
    	<div class="col-sm-12 col-md-12">
    		<div class="mb-3">
    			<label class="form-label">Meta Title </label>
    			<textarea class="form-control" name="metaTitle" placeholder="Meta Title"
    				data-bs-toggle="tooltip" data-bs-placement="top"
    				title="Enter meta title"><?= old('metaTitle'); ?></textarea>
    			<p class="text-danger"><?= session("errors.metaTitle") ?></p>
    		</div>
    	</div>
    	
    	<!-- Meta Keyword -->
    	<div class="col-sm-12 col-md-12">
    		<div class="mb-3">
    			<label class="form-label">Meta Keyword </label>
    			<textarea class="form-control" name="metaKeywords" placeholder="Meta Keyword"
    				data-bs-toggle="tooltip" data-bs-placement="top"
    				title="Enter meta keyword"><?= old('metaKeywords'); ?></textarea>
    			<p class="text-danger"><?= session("errors.metaKeywords") ?></p>
    		</div>
    	</div>
    	
    	<!-- Meta Description -->
    	<div class="col-sm-12 col-md-12">
    		<div class="mb-3">
    			<label class="form-label">Meta Description </label>
    			<textarea class="form-control" name="metaDescription" placeholder="Meta Description"
    				data-bs-toggle="tooltip" data-bs-placement="top"
    				title="Enter meta description"><?= old('metaDescription'); ?></textarea>
    			<p class="text-danger"><?= session("errors.metaDescription") ?></p>
    		</div>
    	</div>
    
    </div>


	
	<!-- Submit Buttons -->
	<div class="text-end settings-bottom-btn mt-0">		
		<button type="submit" class="btn btn-primary">Save Changes</button>
	</div>
</form>

	</div>
</div>



<?= $this->endSection(); ?>