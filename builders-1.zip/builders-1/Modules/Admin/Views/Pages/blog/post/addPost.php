<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>
<style>
.summer-description-box .note-editable {
    min-height: 390px !important;
}

.form-control:disabled,
.form-control[readonly] {
    background: none !important;
}
</style>

<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?= $pageTitle ?></h4>

        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i class="ti ti-refresh"></i></a>
        </li>
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                    class="ti ti-chevron-up"></i></a>
        </li>
    </ul>
    <div class="page-btn mt-0">
        <a href="<?= base_url("admin/profile-list") ?>" class="btn btn-secondary">
            <i data-feather="arrow-left" class="me-2"></i>Back to Category List
        </a>
    </div>
</div>




<div class="content">

    <form action="<?= base_url('admin/blog/add-blog-post') ?>"  method="POST" enctype="multipart/form-data">
        <div class="add-product">
            <div class="accordions-items-seperate" id="accordionSpacingExample">
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingOne">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingOne" aria-expanded="true" aria-controls="SpacingOne">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="info"
                                        class="text-primary me-2"></i><span>Blog Details</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingOne" class="accordion-collapse collapse show" aria-labelledby="headingSpacingOne">
                        <div class="accordion-body border-top">

                            <!-- Post Title -->
                            <div class="row">
                                <div class="col-sm-12 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Title<span
                                                class="text-danger ms-1">*</span></label>
                                        <input type="text" name="title" value="<?= old('title'); ?>" class="form-control" placeholder="Enter blog title">
                                        <p class="text-danger"><?= session("errors.title") ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Category<span
                                                class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="blogCategoryId">
                                            <option value="">Select Category</option>
                                            <?php foreach($getAllCategoryRecord as $category): ?>
                                            <option value="<?= $category->id ?>"><?= $category->name ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="text-danger"><?= session("errors.blogCategoryId") ?></p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Slug<span class="text-danger ms-1">*</span></label>
                                        <input type="text" name="slug" value="<?= old('slug'); ?>"class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Tags <span class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="tagsId">
                                            <?php foreach($getAllTagsRecord as $val): ?>
                                            <option value="<?= $val->id ?>"><?= $val->name ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="text-danger"><?= session("errors.tagsId") ?></p>
                                    </div>
                                </div>

                                <!-- Trending -->
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Trending<span
                                                class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="isFeatured">
                                            <option value="Yes" <?= old('isFeatured') === 'Yes' ? 'selected' : '' ?>>Yes
                                            </option>
                                            <option value="No" <?= old('isFeatured') === 'No' ? 'selected' : '' ?>>No
                                            </option>
                                        </select>
                                        <p class="text-danger"><?= session("errors.isFeatured") ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <!-- Status -->
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Status<span class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="status">
                                            <option value="Active">
                                                Publish</option>
                                            <option value="Block" >
                                                Unpublish</option>
                                        </select>
                                        <p class="text-danger"><?= session("errors.status") ?></p>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Author <span class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="authorId">
                                            <option value="1" selected>Admin</option>
                                        </select>
                                        <p class="text-danger"><?= session("errors.authorId") ?></p>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <!-- Publish -->
                                <div class="col-md-6 col-12 mb-6">
                                    <label for="flatpickr-datetime-post" class="form-label">Publish Date</label>
                                    <input type="text" class="form-control flatpickr-input"
                                        placeholder="YYYY-MM-DD HH:MM" id="flatpickr-datetime-post" name="publishedAt">
                                </div>

                                <!-- Popular -->
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Popular<span class="text-danger ms-1">*</span></label>
                                        <select class="form-control" name="isPopular">
                                            <option value="Yes">No
                                            </option>
                                            <option value="No" >
                                                Yes</option>
                                        </select>
                                        <p class="text-danger"><?= session("errors.isPopular") ?></p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingTwo">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingTwo" aria-expanded="true" aria-controls="SpacingTwo">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="life-buoy"
                                        class="text-primary me-2"></i><span>Content</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingTwo" class="accordion-collapse collapse show" aria-labelledby="headingSpacingTwo">
                        <div class="accordion-body border-top">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Short Content:<span class="text-danger ms-1">*</span></label>
                                        <textarea rows="5" cols="5" class="form-control" name="shortDescription"
                                            placeholder="Enter message"><?= old('shortDescription'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.shortDescription") ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <!-- Editor -->
                                <div class="col-lg-12">
                                    <div class="summer-description-box">
                                        <label class="form-label" for="summernote">Description</label>
                                        <textarea id="summernote" name="content" class="form-control"><?= old('content'); ?></textarea>
                                        <!--<p class="fs-14 mt-1">Maximum 60 Words</p>-->
                                    </div>
                                </div>

                                <!-- /Editor -->
                            </div>

                        </div>
                    </div>
                </div>
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingThree">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingThree" aria-expanded="true" aria-controls="SpacingThree">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="image"
                                        class="text-primary me-2"></i><span>Images</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingThree" class="accordion-collapse collapse show"
                        aria-labelledby="headingSpacingThree">
                        <div class="accordion-body border-top">
                            <div class="row">

                                <!-- Cover Image -->
                                <div class="col-md-6">
                                    <div class="profile-pic-upload">
                                        <div class="profile-pic">
                                            <span>
                                                <i class="ti ti-circle-plus mb-1 fs-16"></i> Cover Image
                                            </span>
                                        </div>
                                        <div class="new-employee-field">
                                            <div class="mb-0">
                                                <div class="image-upload mb-0">
                                                    <input type="file" name="thumbnailImage">
                                                    <div class="image-uploads">
                                                        <h4>Upload Image</h4>
                                                    </div>
                                                </div>
                                                <span class="fs-13 fw-medium mt-2">
                                                    Upload an image below 2 MB, Accepted File format JPG, PNG, JPEG,
                                                    Accepted size 1920*800px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Banner Image -->
                                <div class="col-md-6">
                                    <div class="profile-pic-upload">
                                        <div class="profile-pic">
                                            <span>
                                                <i class="ti ti-circle-plus mb-1 fs-16"></i> Banner Image
                                            </span>
                                        </div>
                                        <div class="new-employee-field">
                                            <div class="mb-0">
                                                <div class="image-upload mb-0">
                                                    <input type="file" name="bannerImage">
                                                    <div class="image-uploads">
                                                        <h4>Upload Image</h4>
                                                    </div>
                                                </div>
                                                <span class="fs-13 fw-medium mt-2">
                                                    Upload an image below 2 MB, Accepted File format JPG, PNG, JPEG,
                                                    Accepted size 1920*800px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Primary SEO -->
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingThree">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingThree" aria-expanded="true" aria-controls="SpacingThree">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="image"
                                        class="text-primary me-2"></i><span>SEO Information</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingThree" class="accordion-collapse collapse show"
                        aria-labelledby="headingSpacingThree">
                        <div class="accordion-body border-top">
                            
                            <!-- Meta Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Meta Title:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="metaTitle"
                                            placeholder="Enter title"><?= old('metaTitle'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.metaTitle") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Meta keyword -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Meta Keyword:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="metaKeywords"
                                            placeholder="Enter keyword"><?= old('metaKeywords'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.metaKeywords") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Meta keyword -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Meta Description:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="metaDescription"
                                            placeholder="Enter Description"><?= old('metaDescription'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.metaDescription") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <!-- Twitter Card -->
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingThree">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingThree" aria-expanded="true" aria-controls="SpacingThree">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="image"
                                        class="text-primary me-2"></i><span>Twitter Card</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingThree" class="accordion-collapse collapse show"
                        aria-labelledby="headingSpacingThree">
                        <div class="accordion-body border-top">
                            
                            <!-- Twitter Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Twitter Title:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="twitterTitle"
                                            placeholder="Enter Title"><?= old('twitterTitle'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.twitterTitle") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Twitter Description -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Twitter Description:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="twitterDescription"
                                            placeholder="Enter Description"><?= old('twitterDescription'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.twitterDescription") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Twitter Card Type -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Twitter Card Type:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="twitterCardType"
                                            placeholder="Enter twitter card type"><?= old('twitterCardType'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.twitterCardType") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">

                                <!-- Twitter Card -->
                                <div class="col-md-12">
                                    <div class="profile-pic-upload">
                                        <div class="profile-pic">
                                            <span>
                                                <i class="ti ti-circle-plus mb-1 fs-16"></i> Twitter Image
                                            </span>
                                        </div>
                                        <div class="new-employee-field">
                                            <div class="mb-0">
                                                <div class="image-upload mb-0">
                                                    <input type="file" name="twitterImage">
                                                    <div class="image-uploads">
                                                        <h4>Upload Image</h4>
                                                    </div>
                                                </div>
                                                <span class="fs-13 fw-medium mt-2">
                                                    Upload an image below 2 MB, Accepted File format JPG, PNG, JPEG,
                                                    Accepted size 1920*800px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <!-- OG TAG -->
                <div class="accordion-item border mb-4">
                    <h2 class="accordion-header" id="headingSpacingThree">
                        <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse"
                            data-bs-target="#SpacingThree" aria-expanded="true" aria-controls="SpacingThree">
                            <div class="d-flex align-items-center justify-content-between flex-fill">
                                <h5 class="d-flex align-items-center"><i data-feather="image"
                                        class="text-primary me-2"></i><span>Og Tags</span></h5>
                            </div>
                        </div>
                    </h2>
                    <div id="SpacingThree" class="accordion-collapse collapse show"
                        aria-labelledby="headingSpacingThree">
                        <div class="accordion-body border-top">
                            
                            <!-- Canonical Url -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Canonical Url:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="canonicalUrl"
                                            placeholder="Enter Title"><?= old('canonicalUrl'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.canonicalUrl") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- OG Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Title:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="ogTitle"
                                            placeholder="Enter Title"><?= old('ogTitle'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.ogTitle") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Og Description -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Og Description:</label>
                                        <textarea rows="5" cols="5" class="form-control" name="ogDescription"
                                            placeholder="Enter Description"><?= old('ogDescription'); ?></textarea>
                                            <p class="text-danger"><?= session("errors.ogDescription") ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">

                                <!-- Og Image -->
                                <div class="col-md-12">
                                    <div class="profile-pic-upload">
                                        <div class="profile-pic">
                                            <span>
                                                <i class="ti ti-circle-plus mb-1 fs-16"></i> Og Image
                                            </span>
                                        </div>
                                        <div class="new-employee-field">
                                            <div class="mb-0">
                                                <div class="image-upload mb-0">
                                                    <input type="file" name="ogImage">
                                                    <div class="image-uploads">
                                                        <h4>Upload Image</h4>
                                                    </div>
                                                </div>
                                                <span class="fs-13 fw-medium mt-2">
                                                    Upload an image below 2 MB, Accepted File format JPG, PNG, JPEG,
                                                    Accepted size 1920*800px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-12">
            <div class="d-flex align-items-center justify-content-end mb-4">
                <button type="submit" class="btn btn-primary">Save Change</button>
            </div>
        </div>
    </form>
</div>


<?= $this->endSection(); ?>
<?= $this->section("js") ?>
<script>
$(document).ready(function() {
    const flatpickrDateTime = document.querySelector('#flatpickr-datetime-post');

    // $('.select2').select2({
    //     placeholder: "Select Tags",
    //     allowClear: true
    // });
    // Datetime
    if (flatpickrDateTime) {
        flatpickrDateTime.flatpickr({
            enableTime: true,
            dateFormat: 'Y-m-d H:i',
            defaultDate: new Date() // current date-time set karne ke liye
        });
    }
});
</script>
<?= $this->endSection(); ?>