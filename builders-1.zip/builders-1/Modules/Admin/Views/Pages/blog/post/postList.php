<?= $this->extend("Modules\Admin\Views\Layouts\MasterLayouts") ?>
<?= $this->section("content") ?>

<div class="page-header">
	<div class="add-item d-flex">
		<div class="page-title">
			<h4 class="fw-bold"><?= $pageTitle ?></h4>
			
		</div>
	</div>
	<ul class="table-top-head">
		
		<li>
			<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
		</li>
	</ul>
	<div class="page-btn mt-0">
		<a href="<?= base_url("admin/profile-list") ?>" class="btn btn-secondary">
			<i data-feather="arrow-left" class="me-2"></i>Back to Category List
		</a>
	</div>
</div>




<!-- Category List Card -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
        <div class="search-set">
            <div class="search-input">
                <span class="btn-searchset">
                    <i class="ti ti-search fs-14 feather-search"></i>
                </span>
            </div>
        </div>
       
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table datatable">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Cover Image</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Tags</th>
                        <th>Status</th>
                        <th>Trending</th>
                        <th>Popular</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sr = 1; ?>
                    <?php foreach($getAllPostRecord as $val): ?>
                        <tr>
                            <td><?= $sr++; ?></td>
                            <td>
                                <?php if (!empty($val->thumbnailImage)) : ?>
                                    <img src="<?= base_url('assets/admin/vijayaagni/blog/seo/' . $val->thumbnailImage) ?>" alt="No Image" width="60">
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?= $val->title ?></td>
                            <td><?= $val->slug ?></td>
                            <td><?= $val->tagsName ?></td>
                            <td><?= $val->status ?></td>
                            <td><?= $val->isFeatured ?></td>
                            <td><?= $val->isPopular ?></td>
                            <td>
                                <a href="<?= base_url('admin/blog/edit-post/'.$val->id); ?>" class="btn text-success" data-bs-toggle="tooltip" data-bs-placement="top"
    				                title="Edit Post">
                                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                </a>
                                <a href="javascript:void(0);" onclick="confirmDelete(<?= $val->id ?>)" class="btn text-danger" data-bs-toggle="tooltip" data-bs-placement="top"
    				               title="Delete Category">
                                    <i class="fa fa-trash-o" aria-hidden="true"></i>
                                </a>                            
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- SweetAlert Delete Confirmation -->
<script>
function confirmDelete(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Redirect to the delete URL
            window.location.href = '<?= base_url("admin/blog/delete-blog-category/") ?>' + id;
        }
    });
}
</script>


<?= $this->endSection(); ?>