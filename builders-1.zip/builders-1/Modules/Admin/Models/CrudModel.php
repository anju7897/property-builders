<?php

namespace Modules\Admin\Models;

use CodeIgniter\Model;

class CrudModel extends Model
{
    
    protected $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = \Config\Database::connect();
    }


    /* ===============================
     Insert Record
    ================================ */
    public function insertRecord(string $table, array $data)
    {
        $builder = $this->db->table($table);
        $builder->insert($data);
        return $this->db->insertID();
    }
    
    /* ===============================
     Get All Record
    ================================ */ 
    public function getAllRecords(string $table, array $where = [], array $orderBy = [])
    {
        $builder = $this->db->table($table)->select('*');

        if (!empty($where)) {
            $builder->where($where);
        }

        if (!empty($orderBy)) {
            foreach ($orderBy as $column => $direction) {
                $builder->orderBy($column, $direction);
            }
        }

        return $builder->get()->getResult();
    }
    
    
    /* ===============================
     Get Single Record
    =============================== */
    public function getSingleRecord(string $table, array $where = [])
    {
        $builder = $this->db->table($table)->select('*');
    
        if (!empty($where)) {
            $builder->where($where);
        }
    
        return $builder->get()->getRow(); 
    }
    
    /* ===============================
     Update Record
    ================================ */
    public function updateRecord(string $table, array $where, array $data)
    {
        $builder = $this->db->table($table);
    
        if (!empty($where)) {
            $builder->where($where);
        }
    
        return $builder->update($data);
    }
    
    /* ===============================
     Delete Record
    ================================ */
    public function deleteRecord(string $table, array $where)
    {
        $builder = $this->db->table($table);
    
        if (!empty($where)) {
            $builder->where($where);
        }
    
        return $builder->delete();
    }
    
    /* ===============================
     Get All Record with Joing Query
    ================================ */
    public function getAllRecordsWithJoingQuery(string $table, array $where = [], array $orderBy = [], array $joins = [])
    {
        $builder = $this->db->table($table)->select('*');
    
        // Join Tables
        if (!empty($joins)) {
            foreach ($joins as $joinTable => $joinCondition) {
                // Support for join type if passed as array
                if (is_array($joinCondition)) {
                    $builder->join($joinTable, $joinCondition['condition'], $joinCondition['type'] ?? 'INNER');
                } else {
                    $builder->join($joinTable, $joinCondition); // Default inner join
                }
            }
        }
    
        // Where Conditions
        if (!empty($where)) {
            $builder->where($where);
        }
    
        // Order By
        if (!empty($orderBy)) {
            foreach ($orderBy as $column => $direction) {
                $builder->orderBy($column, $direction);
            }
        }
    
        return $builder->get()->getResult();
    }
    
    
}