<?php

namespace Modules\Admin\Controllers;
use CodeIgniter\Controller;

    class Dashboard extends Controller
    {
        
        /*========================
        Dashboard 
        =========================*/
        public function dashboard()
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            if($this->request->is('GET'))     
            {
                $data['pageTitle']   =  "Dashboard | Admin";
                $data['pageName']    =  "admin-dashboard";        
                return view('Modules\Admin\Views\Pages\dashboard\dashboard', $data);
        
            }
         
        }
        
        
    }


?>





