<?php

namespace Modules\Admin\Controllers;
use Modules\Admin\Models\CrudModel;

use CodeIgniter\Controller;

    class Blog extends Controller
    {
        
        public function __construct()
        {
            $this->crudModel = new CrudModel();
        }
    
    
        /*========================
         Add Blog
        =========================*/
        public function addCategory()
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            $db = \Config\Database::connect();
            helper(['form']);
            
            // Get Method
            if($this->request->is('GET'))     
            {
                $data['pageTitle']   =  "Add Blog Category";
                $data['pageName']    =  "add-blog-category";        
                return view('Modules\Admin\Views\Pages\blog\category\addCategory', $data);
        
            }
            
            // Post Method
            if ($this->request->is('post')) {
                
                $categoryImageFile = $this->request->getFile('categoryImage');
                $imageRules = '';
            
                if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                    // Apply validations only if image is uploaded
                    $imageRules = 'is_image[categoryImage]|max_size[categoryImage,1024]|max_dims[categoryImage,512,512]';
                }
                
                // Validation Rules
                $validationRules = [
                    'name'                   => 'required|max_length[100]|is_unique[blogCategories.name]',
                    'slug'                   => 'required|alpha_dash|max_length[400]|is_unique[blogCategories.slug]',
                    'isFeatured'             => 'required|max_length[4]',            
                    'status'                 => 'required|max_length[6]',
                    'priorityOrder'          => 'required|max_length[11]',
                    'metaTitle'              => 'permit_empty|max_length[60]',
                    'metaKeywords'           => 'permit_empty|max_length[160]',
                    'metaDescription'        => 'permit_empty|max_length[1200]',
                ];
        
                // Custom Error Messages
                $validationMessages = [
                    'name' => [
                        'required' => 'Category name is required.',
                        'max_length' => 'Category name must not exceed 100 characters.',
                        'is_unique' => 'This category name already exists.',
                    ],
                    'slug' => [
                        'required' => 'Slug is required.',
                        'alpha_dash' => 'Slug must only contain alphanumeric characters, underscores, or dashes.',
                        'max_length' => 'Slug must not exceed 100 characters.',
                        'is_unique' => 'This slug is already in use.',
                    ],
                    'isFeatured' => [
                        'required' => 'Trending is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                    
                    'priorityOrder' => [
                        'required' => 'The priority Order is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                    'isFeatured' => [
                        'required' => 'Trending is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                ];
        
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
        
                $builder = $db->table(' blogCategories');
        
                // Handle file upload
                $categoryImageFile = $this->request->getFile('categoryImage');
                $categoryImageName = '';
                if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                    $categoryImageName = $categoryImageFile->getRandomName();
                    $categoryImageFile->move('assets/admin/vijayaagni/blog/category/', $categoryImageName);
                }
                
                // Arrange Data
        
                $categoryData = [
                    'name'                   => $this->request->getPost('name'),
                    'slug'                   => $this->request->getPost('slug'),
                    'categoryImage'          => $categoryImageName,
                    'isFeatured'             => $this->request->getPost('isFeatured'),
                    'status'                 => $this->request->getPost('status'),
                    'priorityOrder'          => $this->request->getPost('priorityOrder'),
                    'metaTitle'              => $this->request->getPost('metaTitle'),
                    'metaKeywords'            => $this->request->getPost('metaKeywords'),
                    'metaDescription'        => $this->request->getPost('metaDescription'),
                ];
        
                $lastID = $builder->insert($categoryData);
                
                if ($lastID) {
                    $session->setFlashdata('success', 'Category Inserted Successfully');
                    return redirect()->to(base_url('admin/blog/add-blog-category'));
                } else {
                    $session->setFlashdata('error', 'Technical Issue, Please connect to Admin!');
                    return redirect()->to(base_url('admin/blog/add-blog-category'));
                }
            }
        }
        
        
        
        
        /*========================
         Blog Category List
        =========================*/
        public function blogCategoryList() {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            $db = \Config\Database::connect();
                
            $data['pageTitle'] = 'Blog Category List';
            $data['pageName']  = 'blog-category-list';
            
            $db = \Config\Database::connect();
            $builder = $db->table('blogCategories');
            $builder->select('*');
            $builder->where('isDeleted', 'No');
            $builder->orderBy('id', 'DESC');
            $data['getAllCategoryRecord'] = $builder->get()->getResult();
            return view('Modules\Admin\Views\Pages\blog\category\categoryList', $data);
        
        }
        
        
        /*========================
        Update Blog Category 
        =========================*/
        public function editBlogCategory($blogCategoryId)
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
        
            $db = \Config\Database::connect();
           
        
            // GET Method
            if ($this->request->is('get')) {
                $data['pageTitle'] = 'Edit Blog Category';
                $data['pageName'] = 'blog-category-list';
        
                $builder = $db->table('blogCategories');
                $builder->where('id', $blogCategoryId);
                $data['getSingleBlogCategoryRecord'] = $builder->get()->getRow();
                
                
        
                return view('Modules\Admin\Views\Pages\/blog\category\editBlogCategory', $data);
            }
        
            // POST Method
            if ($this->request->is('post')) {
        
                $categoryImageFile = $this->request->getFile('categoryImage');
                $imageRules = '';
        
                if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                    $imageRules = 'is_image[categoryImage]|max_size[categoryImage,1024]|max_dims[categoryImage,512,512]';
                }
        
                // Base validation rules
                $validationRules = [
                    'name'          => 'required|max_length[100]',
                    'slug'          => 'required|alpha_dash|max_length[400]',
                    'isFeatured'    => 'required|max_length[4]',
                    'status'        => 'required|max_length[6]',
                    'priorityOrder' => 'required|max_length[11]',
                    'metaTitle'     => 'permit_empty|max_length[60]',
                    'metaKeywords'  => 'permit_empty|max_length[160]',
                    'metaDescription' => 'permit_empty|max_length[1200]',
                ];
        
                // Add image rules if image is uploaded
                if (!empty($imageRules)) {
                    $validationRules['categoryImage'] = $imageRules;
                }
        
                // Validation messages
                $validationMessages = [
                    'name' => [
                        'required' => 'Category name is required.',
                        'max_length' => 'Category name must not exceed 100 characters.',
                    ],
                    'slug' => [
                        'required' => 'Slug is required.',
                        'alpha_dash' => 'Slug must only contain alphanumeric characters, underscores, or dashes.',
                        'max_length' => 'Slug must not exceed 400 characters.',
                    ],
                    'isFeatured' => [
                        'required' => 'Trending is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                    'priorityOrder' => [
                        'required' => 'The priority order is required.',
                        'max_length' => 'Priority order must not exceed 11 characters.',
                    ],
                    'categoryImage' => [
                        'is_image' => 'Uploaded file must be an image.',
                        'max_size' => 'Image size must not exceed 1MB.',
                        'max_dims' => 'Image dimensions must not exceed 512x512 pixels.',
                    ],
                ];
        
                // Run validation
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
        
                // Duplicate name or slug check
                $builder = $db->table('blogCategories');
                $name = $this->request->getPost('name');
                $slug = $this->request->getPost('slug');
        
                $duplicate = $builder
                    ->groupStart()
                        ->where('name', $name)
                        ->orWhere('slug', $slug)
                    ->groupEnd()
                    ->where('id !=', $blogCategoryId)
                    ->where('isDeleted', 'No')
                    ->get()
                    ->getRow();
        
                if ($duplicate) {
                    $errors = [];
                    if ($duplicate->name === $name) {
                        $errors['name'] = 'This category name already exists.';
                    }
                    if ($duplicate->slug === $slug) {
                        $errors['slug'] = 'This slug is already in use.';
                    }
        
                    return redirect()->back()->withInput()->with('errors', $errors);
                }
        
                // Prepare update data
                $categoryData = [
                    'name'           => $name,
                    'slug'           => $slug,
                    'isFeatured'     => $this->request->getPost('isFeatured'),
                    'status'         => $this->request->getPost('status'),
                    'priorityOrder'  => $this->request->getPost('priorityOrder'),
                    'metaTitle'      => $this->request->getPost('metaTitle'),
                    'metaKeywords'   => $this->request->getPost('metaKeywords'),
                    'metaDescription'=> $this->request->getPost('metaDescription'),
                ];
        
                // Upload and set image if provided
                if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                    $categoryImageName = $categoryImageFile->getRandomName();
                    $categoryImageFile->move('assets/admin/vijayaagni/blog/category/', $categoryImageName);
                    $categoryData['categoryImage'] = $categoryImageName;
                }
        
                // Update the record
                $builder = $db->table('blogCategories');
                $builder->where('id', $blogCategoryId);
                $updated = $builder->update($categoryData);
        
                if ($updated) {
                    $session->setFlashdata('success', 'Category updated successfully.');
                } else {
                    $session->setFlashdata('error', 'Failed to update category.');
                }
        
                return redirect()->to(base_url('admin/blog/blog-category-list'));
            }
        }
        
        
        /*========================
         Delete Blog Category
        =========================*/
        public function deletBlogCategory($blogCategoryId) {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
                
            $data['pageTitle'] = 'Delete Blog Category';
            $data['pageName']  = 'delete-blog-Category';
            
           
            $getSingleBlogCategory = $model->getSingleRecord('blogCategories', ['id' => $blogCategoryId]);
            
            if($getSingleBlogCategory) {
                
               
                $categoryData = [
                    'isDeleted'           => 'Yes',
                    'status'              => 'Block',
                    'updatedAt'           => date('Y-m-d H:i:s')
                ];
                
               $model = new CrudModel();
               $updated = $model->updateRecord('blogCategories', ['id' => $blogCategoryId], $categoryData);
               
               if($updated) {
                   $session->setFlashdata('success', 'Category Deleted successfully.');
               } else {
                    $session->setFlashdata('error', 'Technical Issues, Failed to Delete Category. Connect to Admin');
               }
                
            } else {
                $session->setFlashdata('error', 'Technical Issues, Failed to Delete Tags. Connect to Admin');
            }
            return redirect()->to(base_url('admin/blog/blog-category-list'));
        
        }
        
        
        /*========================
         Add Tags
        =========================*/
        public function addTags() {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            $db = \Config\Database::connect();
            helper(['form']);
            
            // Get Method
            if($this->request->is('GET'))     
            {
                $data['pageTitle']   =  "Add Blog Tags";
                $data['pageName']    =  "blog-tags";        
                return view('Modules\Admin\Views\Pages\blog\tags\addTags', $data);
            }
            
            // Post Method
            if ($this->request->is('post')) {
                
                // Validation Rules
                $validationRules = [
                    'name'                   => 'required|max_length[45]|is_unique[tags.name]',
                    'status'                 => 'required|max_length[6]',
                ];
        
                // Custom Error Messages
                $validationMessages = [
                    'name' => [
                        'required' => 'Tags name is required.',
                        'max_length' => 'Tags name must not exceed 45 characters.',
                        'is_unique' => 'This Tags name already exists.',
                    ],
        
                    'status' => [
                        'required' => 'The Status is required.',
                        'max_length' => 'The Status must not exceed 6 characters.',
                    ],
                ];
        
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
                
                // Arrange Data
                $tagsData = [
                    'name'                     => $this->request->getPost('name'),
                    'status'                   => $this->request->getPost('status'),
                ];
                
                $model = new CrudModel();
                $lastID = $model->insertRecord('tags', $tagsData);
                
                if ($lastID) {
                    $session->setFlashdata('success', 'Tags Inserted Successfully');
                    return redirect()->to(base_url('admin/blog/blog-tags-list'));
                } else {
                    $session->setFlashdata('error', 'Technical Issue, Please connect to Admin!');
                    return redirect()->to(base_url('admin/blog/blog-tags-list'));
                }
            }
        }
        
        
        /*========================
         Blog Tags List
        =========================*/
        public function blogTagsList() {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
           
                
            $data['pageTitle'] = 'Blog Category List';
            $data['pageName']  = 'blog-tags-list';
            
            $model = new CrudModel();
            $data['getAllTagsRecord'] = $model->getAllRecords('tags', ['isDeleted' => 'No'], ['id' => 'ASC']);
            return view('Modules\Admin\Views\Pages\blog\tags\tagsList', $data);
        
        }
        
        /*========================
         Update Blog Tags
        =========================*/
        public function editBlogTags($blogTagsId)
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            // GET Method
            if ($this->request->is('get')) {
                $data['pageTitle'] = 'Edit Blog Tags';
                $data['pageName'] = 'blog-tags-list';
        
                $model = new CrudModel();
                $data['getSingleBlogTagsRecord'] = $model->getSingleRecord('tags', ['id' => $blogTagsId]);
                return view('Modules\Admin\Views\Pages\blog\tags\editBlogTags', $data);
            }
        
            // POST Method
            if ($this->request->is('post')) {
        
               // Validation Rules
                $validationRules = [
                    'name'                   => 'required|max_length[45]',
                    'status'                 => 'required|max_length[6]',
                ];
        
                // Custom Error Messages
                $validationMessages = [
                    'name' => [
                        'required' => 'Tags name is required.',
                        'max_length' => 'Tags name must not exceed 45 characters.',
                    ],
        
                    'status' => [
                        'required' => 'The Status is required.',
                        'max_length' => 'The Status must not exceed 6 characters.',
                    ],
                ];
        
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
        
               
                $name = $this->request->getPost('name');
               
                
                // Duplicate name or slug check
                $db = \Config\Database::connect();
                $builder = $db->table('tags');
                $duplicate = $builder
                    ->where('name', $name)
                    ->where('id !=', $blogTagsId)
                    ->where('isDeleted', 'No')
                    ->get()
                    ->getRow();
        
                if ($duplicate) {
                    $errors = [];
                    if ($duplicate->name === $name) {
                        $errors['name'] = 'This category name already exists.';
                    }
                    
                    return redirect()->back()->withInput()->with('errors', $errors);
                }
        
                // Prepare update data
                $tagsData = [
                    'name'           => $name,
                    'status'         => $this->request->getPost('status'),
                ];
                
               $model = new CrudModel();
               $updated = $model->updateRecord('tags', ['id' => $blogTagsId], $tagsData);
        
                if ($updated) {
                    $session->setFlashdata('success', 'Tags updated successfully.');
                } else {
                    $session->setFlashdata('error', 'Technical Issues, Failed to update Tags.');
                }
        
                return redirect()->to(base_url('admin/blog/blog-tags-list'));
            }
        }
        
        
        /*========================
         Delete Blog Tags List
        =========================*/
        public function deletBlogTags($blogTagsId) {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
                
            $data['pageTitle'] = 'Delete Blog Tags';
            $data['pageName']  = 'delete-blog-tags';
            
            $model = new CrudModel();
            $getSingleBlogTags = $model->getSingleRecord('tags', ['id' => $blogTagsId]);
            
            if($getSingleBlogTags) {
                
                $tagsData = [
                    'isDeleted'           => 'Yes',
                    'status'              => 'Block',
                    'updatedAt'           => date('Y-m-d H:i:s')
                ];
                
               $model = new CrudModel();
               $updated = $model->updateRecord('tags', ['id' => $blogTagsId], $tagsData);
               
               if($updated) {
                   $session->setFlashdata('success', 'Tags Deleted successfully.');
               } else {
                    $session->setFlashdata('error', 'Technical Issues, Failed to Delete Tags. Connect to Admin');
               }
                
            } else {
                $session->setFlashdata('error', 'Technical Issues, Failed to Delete Tags. Connect to Admin');
            }
            return redirect()->to(base_url('admin/blog/blog-tags-list'));
        
        }
        
        /*========================
         Add Post
        =========================*/
        public function addPost()
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
            
            // Get Method
            if($this->request->is('GET'))     
            {
                $model = new CrudModel();
                $data['pageTitle']               =  "Add Blog Post";
                $data['pageName']                =  "add-blog-post";
               
                $data['getAllTagsRecord']        = $model->getAllRecords('tags', ['isDeleted' => 'No'], ['id' => 'DESC']);
                $data['getAllCategoryRecord']    = $model->getAllRecords('blogCategories', ['isDeleted' => 'No'], ['id' => 'DESC']);
                return view('Modules\Admin\Views\Pages\blog\post\addPost', $data);
        
            }
            
            // Post Method
            if ($this->request->is('post')) {
                
              
                
                // Validation Rules
                $validationRules = [
                    'title'                   => 'required|max_length[800]',
                    'slug'                    => 'required|alpha_dash|max_length[400]|is_unique[blogPosts.slug]',
                    'isFeatured'             => 'required|max_length[4]',            
                    'status'                 => 'required|max_length[6]',
                    'publishedAt'            => 'required',
                    'shortDescription'       => 'required'
                ];
        
                // Custom Error Messages
                $validationMessages = [
                    'title' => [
                        'required' => 'Title name is required.',
                        'max_length' => 'Title name must not exceed 800 characters.',
                    ],
                    'slug' => [
                        'required' => 'Slug is required.',
                        'alpha_dash' => 'Slug must only contain alphanumeric characters, underscores, or dashes.',
                        'max_length' => 'Slug must not exceed 100 characters.',
                        'is_unique' => 'This slug is already in use.',
                    ],
                    'isFeatured' => [
                        'required' => 'Trending is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                    'isFeatured' => [
                        'required' => 'Trending is required.',
                        'max_length' => 'Trending must not exceed 4 characters.',
                    ],
                    'publishedAt' => [
                        'required' => 'Publish Date is required.',
                    ],
                ];
        
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
        
                // Cover Image
                $thumbnailImage = $this->request->getFile('thumbnailImage');
                $thumbnailImageName = '';
                if ($thumbnailImage && $thumbnailImage->isValid() && !$thumbnailImage->hasMoved()) {
                    $thumbnailImageName = $thumbnailImage->getRandomName();
                    $thumbnailImage->move('assets/admin/vijayaagni/blog/seo/', $thumbnailImageName);
                }
                
                // Banner Image
                $bannerImage = $this->request->getFile('bannerImage');
                $bannerImageName = '';
                if ($bannerImage && $bannerImage->isValid() && !$bannerImage->hasMoved()) {
                    $bannerImageName = $bannerImage->getRandomName();
                    $bannerImage->move('assets/admin/vijayaagni/blog/seo/', $bannerImageName);
                }
                
                // Twitter Card Image
                $twitterImage = $this->request->getFile('twitterImage');
                $twitterImageName = '';
                if ($twitterImage && $twitterImage->isValid() && !$twitterImage->hasMoved()) {
                    $twitterImageName = $twitterImage->getRandomName();
                    $twitterImage->move('assets/admin/vijayaagni/blog/seo/', $twitterImageName);
                }
                
                
                // Og Image
                $ogImage = $this->request->getFile('ogImage');
                $ogImageName = '';
                if ($ogImage && $ogImage->isValid() && !$ogImage->hasMoved()) {
                    $ogImageName = $ogImage->getRandomName();
                    $ogImage->move('assets/admin/vijayaagni/blog/seo/', $ogImageName);
                }
                
                $postData = [
                    'title'                            => $this->request->getPost('title'),
                    'slug'                             => $this->request->getPost('slug'),
                    'blogCategoryId'                   => $this->request->getPost('blogCategoryId'),
                    'isFeatured'                       => $this->request->getPost('isFeatured'),
                    'status'                           => $this->request->getPost('status'),
                    'tagsId'                           => $this->request->getPost('tagsId'),
                    'authorId'                         => $this->request->getPost('authorId'),
                    'publishedAt'                      => $this->request->getPost('publishedAt'),
                    'isPopular'                        => $this->request->getPost('isPopular'),
                    'shortDescription'                 => $this->request->getPost('shortDescription'),
                    'content'                          => $this->request->getPost('content'),
                    'thumbnailImage'                   => $this->request->getPost('thumbnailImage'),
                    'metaTitle'                        => $this->request->getPost('metaTitle'),
                    'metaKeywords'                     => $this->request->getPost('metaKeywords'),
                    'metaDescription'                  => $this->request->getPost('metaDescription'),
                    'twitterTitle'                     => $this->request->getPost('twitterTitle'),
                    'twitterDescription'               => $this->request->getPost('twitterDescription'),
                    'twitterCardType'                  => $this->request->getPost('twitterCardType'),
                    'canonicalUrl'                     => $this->request->getPost('canonicalUrl'),
                    'ogTitle'                          => $this->request->getPost('ogTitle'),
                    'ogDescription'                    => $this->request->getPost('ogDescription'),
                    'ogImage'                          => $ogImageName,
                    'bannerImage'                      => $bannerImageName,
                    'thumbnailImage'                   => $thumbnailImageName,
                    'twitterImage'                     => $twitterImageName,
                ];
        
                $model = new CrudModel();
                $lastID = $model->insertRecord('blogPosts', $postData);
                
                if ($lastID) {
                    $session->setFlashdata('success', 'Post Publish Successfully');
                    return redirect()->to(base_url('admin/blog/add-blog-post'));
                } else {
                    $session->setFlashdata('error', 'Technical Issue, Please connect to Admin!');
                    return redirect()->to(base_url('admin/blog/add-blog-post'));
                }
            }
        }
        
        
        /*========================
         Post List - Blog
        =========================*/
        public function postList() 
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
        
            $data['pageTitle'] = 'Post List';
            $data['pageName']  = 'post-list';
        
            $db = \Config\Database::connect();
        
            // Query builder with JOIN
            $builder = $db->table('blogPosts');
            $builder->select('blogPosts.*, tags.name as tagsName');
            $builder->join('tags', 'tags.id = blogPosts.blogCategoryId', 'left');
            $builder->where('blogPosts.isDeleted', 'No');
            $builder->orderBy('blogPosts.id', 'DESC');
            
            $query = $builder->get();
            $data['getAllPostRecord'] = $query->getResult();
            return view('Modules\Admin\Views\Pages\blog\post\postList', $data);
        }
        
        // Update
        public function editPost($postId)
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
        
            $model = new CrudModel();
        
            // GET Method
            if ($this->request->is('get')) {
                $data['pageTitle'] = 'Edit Blog Post';
                $data['pageName'] = 'edit-blog-post';
        
                $data['getAllTagsRecord'] = $model->getAllRecords('tags', ['isDeleted' => 'No'], ['id' => 'ASC']);
                $data['getAllCategoryRecord'] = $model->getAllRecords('blogCategories', ['isDeleted' => 'No'], ['id' => 'DESC']);
                $data['getSingleBlogPostRecord'] = $model->getSingleRecord('blogPosts', ['id' => $postId]);
        
                return view('Modules\Admin\Views\Pages\blog\post\editPost', $data);
            }
        
            // POST Method
            if ($this->request->is('post')) {
                $validationRules = [
                    'title' => 'required|max_length[800]',
                    'slug' => "required|alpha_dash|max_length[400]|is_unique[blogPosts.slug,id,{$postId}]",
                    'isFeatured' => 'required|max_length[4]',
                    'status' => 'required|max_length[6]',
                    'publishedAt' => 'required',
                    'shortDescription' => 'required'
                ];
        
                $validationMessages = [
                    'title.required' => 'Title is required.',
                    'slug.required' => 'Slug is required.',
                    'slug.is_unique' => 'This slug is already in use.',
                    'isFeatured.required' => 'Trending is required.',
                    'status.required' => 'Status is required.',
                    'publishedAt.required' => 'Publish Date is required.',
                    'shortDescription.required' => 'Short Description is required.',
                ];
        
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
        
                // Image Handling
                $fields = ['thumbnailImage', 'bannerImage', 'twitterImage', 'ogImage'];
                $uploadPath = 'assets/admin/vijayaagni/blog/seo/';
                $imageNames = [];
        
                foreach ($fields as $field) {
                    $file = $this->request->getFile($field);
                    if ($file && $file->isValid() && !$file->hasMoved()) {
                        $imageName = $file->getRandomName();
                        $file->move($uploadPath, $imageName);
                        $imageNames[$field] = $imageName;
                    }
                }
        
                // Collect updated data
                $postData = [
                    'title' => $this->request->getPost('title'),
                    'slug' => $this->request->getPost('slug'),
                    'blogCategoryId' => $this->request->getPost('blogCategoryId'),
                    'isFeatured' => $this->request->getPost('isFeatured'),
                    'status' => $this->request->getPost('status'),
                    'tagsId' => $this->request->getPost('tagsId'),
                    'authorId' => $this->request->getPost('authorId'),
                    'publishedAt' => $this->request->getPost('publishedAt'),
                    'isPopular' => $this->request->getPost('isPopular'),
                    'shortDescription' => $this->request->getPost('shortDescription'),
                    'content' => $this->request->getPost('content'),
                    'metaTitle' => $this->request->getPost('metaTitle'),
                    'metaKeywords' => $this->request->getPost('metaKeywords'),
                    'metaDescription' => $this->request->getPost('metaDescription'),
                    'twitterTitle' => $this->request->getPost('twitterTitle'),
                    'twitterDescription' => $this->request->getPost('twitterDescription'),
                    'twitterCardType' => $this->request->getPost('twitterCardType'),
                    'canonicalUrl' => $this->request->getPost('canonicalUrl'),
                    'ogTitle' => $this->request->getPost('ogTitle'),
                    'ogDescription' => $this->request->getPost('ogDescription')
                ];
        
                // Merge new image filenames if uploaded
                $postData = array_merge($postData, $imageNames);
        
                // Update the record
                $updated = $model->updateRecord('blogPosts', ['id' => $postId], $postData);
        
                if ($updated) {
                    $session->setFlashdata('success', 'Post updated successfully.');
                } else {
                    $session->setFlashdata('error', 'Technical issue, failed to update post.');
                }
        
                return redirect()->to(base_url('admin/blog/post-list'));
            }
        }

        
    }


?>





