<?php

namespace Modules\Admin\Controllers;
use CodeIgniter\Controller;

    class AdminLogin extends Controller
    {
        /* ==========================
         Super Admin Login
        =========================== */
        public function adminLogin()
        {
            $session = session();
        
            if ($session->get('logged_in')) {
                return redirect()->to(base_url('admin/dashboard'));
            }
        
            // GET request
            if ($this->request->is('GET')) {
                $data['pageTitle'] = "Login | Admin";
                $data['pageName'] = "login-admin";
                return view('Modules\Admin\Views\Pages\login\admin-login', $data);
            }
        
            // POST request
            if ($this->request->is('POST')) {
                // Step 1: Verify Google reCAPTCHA
                $recaptchaResponse = $this->request->getPost('g-recaptcha-response');
                $secret = '6LdpCGorAAAAAJbc_Q57Pte0FD9reUonPWV_ugG7';
        
                $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secret}&response={$recaptchaResponse}");
              
                $captchaSuccess = json_decode($verify);
        
                if (!$captchaSuccess->success) {
                    $session->setFlashdata('captcha_error', 'reCAPTCHA verification failed. Please try again.');
                    return redirect()->to(base_url('admin/login'))->withInput();
                }
        
                // Step 2: Login Logic
                $email    = $this->request->getPost('emailId');
                $password = $this->request->getPost('password');
        
                $db = \Config\Database::connect();
                $builder = $db->table('admin');
                $builder->select('*');
                $builder->where([
                    'emailId'  => $email,
                    'userType' => 'A',
                    'status'   => 'Active',
                    'isDeleted'=> 'No',
                ]);
        
                $userDetails = $builder->get()->getRow();
                
                if(!$userDetails) {
                     $session->setFlashdata('error', 'Invalid Email ID');
                    return redirect()->to(base_url('admin/login'))->withInput();
                }
        
                if ($userDetails && password_verify($password, $userDetails->password)) {
                    
                    $db = \Config\Database::connect();
                    $builder = $db->table('setting');
                    $builder->select('logo, favIcon');
                    $builder->where('id', '1');
                    $getSingleRecord = $builder->get()->getRow();
                    $sessionData = [
                        'emailId'  => $userDetails->emailId,
                        'userType' => $userDetails->userType,
                        'status'   => $userDetails->status,
                        'fullName' => $userDetails->fullName,
                        'id'       => $userDetails->id,
                        'logo'     => $getSingleRecord->logo,
                        'favIcon'  => $getSingleRecord->favIcon,
                        'logged_in'=> true
                    ];
                        session()->set($sessionData);
                    $session->set($sessionData);
                    $session->setFlashdata('success', 'Login Suceess');
                    return redirect()->to(base_url('admin/dashboard'));
                } else {
                    $session->setFlashdata('error', 'Invalid Password');
                    return redirect()->to(base_url('admin/login'))->withInput();
                }
            }
        }
        
        
        public function logout()
        {
            $session = session();
        
            if (!$session->get('logged_in')) {
                // If not logged in, redirect to login
                return redirect()->to(base_url('admin/login'));
            }
        
            // Destroy session and logout
            $session->destroy();
            return redirect()->to(base_url('admin/login'))->with('success', 'You have been logged out successfully.');
        }
        
    }


?>





