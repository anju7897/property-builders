<?php

namespace Modules\Admin\Controllers;
use Modules\Admin\Models\CrudModel;

use CodeIgniter\Controller;

    class Banner extends Controller
    {
        
        public function __construct()
        {
            $this->crudModel = new CrudModel();
        }
    
    
        /*========================
         Add Blog
        =========================*/
        public function addBanner()
        {
            
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }           
         
            
        // GET Method – Load Form
        if ($this->request->is('get')) {
            $data['pageTitle'] = "Add Banner";
            $data['pageName']  = "add-banner";
            return view('Modules\Admin\Views\Pages\banner\addBanner', $data);
        }

        // POST Method – Handle Form Submission
        if ($this->request->is('post')) {
            $bannerImageFile = $this->request->getFile('bannerImage');

            // Base validation rules
            $validationRules = [
                'buttonTextOne'   => 'permit_empty|max_length[600]',
                'buttonLinkOne'   => 'permit_empty|valid_url|max_length[600]',
                'buttonTextTwo'   => 'permit_empty|max_length[600]',
                'buttonLinkTwo'   => 'permit_empty|valid_url|max_length[500]',
            ];

            // Base validation messages
            $validationMessages = [
                'buttonTextOne' => [
                    'required'   => 'Button Text 1 is required.',
                    'max_length' => 'Button Text 1 must not exceed 100 characters.',
                ],
                'buttonLinkOne' => [
                    'required'   => 'Button Link 1 is required.',
                    'valid_url'  => 'Please enter a valid URL.',
                    'max_length' => 'Button Link 1 must not exceed 500 characters.',
                ],
                'buttonTextTwo' => [
                    'max_length' => 'Button Text 2 must not exceed 100 characters.',
                ],
                'buttonLinkTwo' => [
                    'valid_url'  => 'Please enter a valid URL.',
                    'max_length' => 'Button Link 2 must not exceed 500 characters.',
                ],
            ];

            // Conditionally add image validation only if file selected
            if ($bannerImageFile && $bannerImageFile->isValid() && !$bannerImageFile->hasMoved()) {
                $validationRules['bannerImage'] = 'uploaded[bannerImage]|is_image[bannerImage]|max_size[bannerImage,1024]|max_dims[bannerImage,18000,1800]';

                $validationMessages['bannerImage'] = [
                    'uploaded'  => 'Banner image is required.',
                    'is_image'  => 'Only valid image files are allowed.',
                    'max_size'  => 'Image size must not exceed 4MB.',
                    'max_dims'  => 'Image dimensions must not exceed 18000x18000 pixels.',
                ];
            }

            // Run Validation
            if (!$this->validate($validationRules, $validationMessages)) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }

            // Upload the image if valid
            $bannerImageName = '';
            if ($bannerImageFile && $bannerImageFile->isValid() && !$bannerImageFile->hasMoved()) {
                $bannerImageName = $bannerImageFile->getRandomName();
                $bannerImageFile->move('assets/admin/auPair/images/banner', $bannerImageName);
            }

            // Prepare data for insert
            $bannerData = [
                'bannerImage'    => $bannerImageName,
                'buttonTextOne'  => $this->request->getPost('buttonTextOne'),
                'buttonLinkOne'  => $this->request->getPost('buttonLinkOne'),
                'buttonTextTwo'  => $this->request->getPost('buttonTextTwo'),
                'buttonLinkTwo'  => $this->request->getPost('buttonLinkTwo'),
            ];

            // Insert data
            $model = new CrudModel();
            $lastID = $model->insertRecord('banner', $bannerData);

            if ($lastID) {
                $session->setFlashdata('success', 'Banner added successfully.');
                return redirect()->to(base_url('admin/banner/add-banner'));
            } else {
                $session->setFlashdata('error', 'Technical issue! Please try again.');
                return redirect()->to(base_url('admin/banner/add-banner'));
            }
        }

        }

        public function listBanner()
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }

            $model = new CrudModel();

            // Assuming getAllRecords is your custom method to fetch all rows from a table
            $data['banners'] = $model->getAllRecords('banner');
            
            $data['pageTitle'] = "Banner List";
            $data['pageName']  = "list-banner";

            return view('Modules\Admin\Views\Pages\banner\listBanner', $data);
        }

        public function deleteBanner($id)
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }

            $model = new CrudModel();

            // Get the banner record by ID
            $banner = $model->getSingleRecord('banner', ['id' => $id]);

            if ($banner) {
                // Check and delete image file
                $imagePath = FCPATH . 'assets/admin/auPair/images/banner/' . $banner->bannerImage;

                if (!empty($banner->bannerImage) && file_exists($imagePath)) {
                    unlink($imagePath); // delete the image from folder
                }

                // Delete from database
                $deleted = $model->deleteRecord('banner', ['id' => $id]);

                if ($deleted) {
                    $session->setFlashdata('success', 'Banner deleted successfully.');
                } else {
                    $session->setFlashdata('error', 'Unable to delete banner. Please try again.');
                }
            } else {
                $session->setFlashdata('error', 'Banner not found.');
            }

            return redirect()->to(base_url('admin/banner/list-banner'));
        }


        public function editBanner($id)
        {
            $session = session();
            helper(['form', 'url']);

            // Session Check
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }

            $model = new CrudModel();

            // GET method — load edit form
            if ($this->request->is('get')) {
                $data['banner'] = $model->getSingleRecord('banner', ['id' => $id]);
                $data['pageTitle'] = "Edit Banner";
                $data['pageName']  = "edit-banner";
                return view('Modules\Admin\Views\Pages\banner\editBanner', $data);
            }

            // POST method — handle update
            if ($this->request->is('post')) {
                $bannerImageFile = $this->request->getFile('bannerImage');

                // Validation rules
                $validationRules = [
                    'buttonTextOne' => 'required|max_length[100]',
                    'buttonLinkOne' => 'required|valid_url|max_length[500]',
                    'buttonTextTwo' => 'permit_empty|max_length[100]',
                    'buttonLinkTwo' => 'permit_empty|valid_url|max_length[500]',
                ];

                $validationMessages = [
                    'buttonTextOne' => [
                        'required' => 'Button Text 1 is required.',
                        'max_length' => 'Button Text 1 must not exceed 100 characters.',
                    ],
                    'buttonLinkOne' => [
                        'required' => 'Button Link 1 is required.',
                        'valid_url' => 'Please enter a valid URL.',
                        'max_length' => 'Button Link 1 must not exceed 500 characters.',
                    ],
                    'buttonTextTwo' => [
                        'max_length' => 'Button Text 2 must not exceed 100 characters.',
                    ],
                    'buttonLinkTwo' => [
                        'valid_url' => 'Please enter a valid URL.',
                        'max_length' => 'Button Link 2 must not exceed 500 characters.',
                    ],
                ];
                
                if ($bannerImageFile && $bannerImageFile->isValid() && !$bannerImageFile->hasMoved()) {
                    $validationRules['bannerImage'] = 'uploaded[bannerImage]|is_image[bannerImage]|max_size[bannerImage,1024]|max_dims[bannerImage,1000,1000]';
                    $validationMessages['bannerImage'] = [
                        'uploaded'  => 'Banner image is required.',
                        'is_image'  => 'Only valid image files are allowed.',
                        'max_size'  => 'Image size must not exceed 1MB.',
                        'max_dims'  => 'Image dimensions must not exceed 1000x1000 pixels.',
                    ];
                }

                // Validate the form
                if (!$this->validate($validationRules, $validationMessages)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }

                // Fetch existing banner
                $existing = $model->getSingleRow('banner', ['id' => $id]);

                // Handle image upload
                $bannerImageName = $existing->bannerImage ?? '';
                if ($bannerImageFile && $bannerImageFile->isValid() && !$bannerImageFile->hasMoved()) {
                    $bannerImageName = $bannerImageFile->getRandomName();
                    $bannerImageFile->move('assets/admin/images/banner', $bannerImageName);

                    // Delete old image
                    if (!empty($existing->bannerImage) && file_exists('assets/admin/images/banner/' . $existing->bannerImage)) {
                        unlink('assets/admin/images/banner/' . $existing->bannerImage);
                    }
                }

                // Prepare update data
                $updateData = [
                    'bannerImage'    => $bannerImageName,
                    'buttonTextOne'  => $this->request->getPost('buttonTextOne'),
                    'buttonLinkOne'  => $this->request->getPost('buttonLinkOne'),
                    'buttonTextTwo'  => $this->request->getPost('buttonTextTwo'),
                    'buttonLinkTwo'  => $this->request->getPost('buttonLinkTwo'),
                ];

                // Update record
                $updated = $model->updateRecord('banner', ['id' => $id], $updateData);

                if ($updated) {
                    $session->setFlashdata('success', 'Banner updated successfully.');
                } else {
                    $session->setFlashdata('error', 'No changes made or update failed.');
                }

                return redirect()->to(base_url('admin/banner/edit-banner/' . $id));
            }
        }

}
        
        
        
    
    