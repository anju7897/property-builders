<?php

namespace Modules\Admin\Controllers;
use CodeIgniter\Controller;
use Modules\Admin\Models\CrudModel;

class Product extends Controller {
    
    /* ====================================
     Add Product
    ===================================== */
    public function addProduct()
    {
        $session = session();
        $crudModel = new CrudModel();
        helper('custom'); 

    
        if ($this->request->is('GET')) {
            $data['pageTitle'] = "Add Banner";
            $data['pageName'] = "add-product";  
            $data['getAllBrand'] = $crudModel->getAllRecords('brand', ['status' => 'Active', 'isDeleted' => 'No'], ['id' => 'DESC']);
            $data['getAllGst'] = $crudModel->getAllRecords('gst', ['status' => 'Active', 'isDeleted' => 'No'], ['id' => 'ASC']);
            $data['getAllCategoryRecords'] = $crudModel->getAllRecords('category',['isDeleted' => 'No','parentId'  => 0,],['id' => 'DESC']);
            $data['autoSKU'] = generateSKU('PRD');
            return view('Modules\Admin\Views\Pages\products\addProduct', $data);
        }
    
        if ($this->request->is('post')) {
            $validationRules = [
                'name'                          => 'required|max_length[150]',
                'slug'                          => 'required|alpha_dash|max_length[255]',
                'status'                        => 'required|max_length[7]',
                'sku'                           => 'required|max_length[10]|is_unique[products.sku]',
                'mainCategory'                  => 'required|max_length[10]',
                'childCategory'                 => 'required|max_length[10]',
                'brandId'                       => 'required|max_length[10]',
                'buyingPrice'                   => 'required|decimal|max_length[10]',
                'sellingPrice'                  => 'required|decimal|max_length[10]',
                'stock'                         => 'required|decimal|max_length[10]',
                'gst'                           => 'required|numeric|max_length[1]',
                'weight'                        => 'required|decimal|max_length[10]',
                'length'                        => 'required|decimal|max_length[10]',
                'width'                         => 'required|decimal|max_length[150]',
                'height'                        => 'required|decimal|max_length[150]',
                'shortDescription'              => 'required|max_length[1000]',
                'longDescription'               => 'required',
                'canPurchasable'                => 'required|max_length[3]',
                'stockStatus'                  => 'required|max_length[7]',
                'refundable'                    => 'required|max_length[3]',
                'cod'                           => 'required|max_length[3]',
                'trending'                      => 'required|max_length[3]'
            ];
        
            if (!$this->validate($validationRules)) {
                print_r($this->validator->getErrors()); die;
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
        
            $stock = $this->request->getPost('stock') ?? 0; // Opening stock
        
            // Product Data
            $productData = [
                'name'                        => $this->request->getPost('name'),
                'slug'                        => $this->request->getPost('slug'),
                'sku'                         => $this->request->getPost('sku'),
                'mainCategory'                => $this->request->getPost('mainCategory'),
                'childCategory'               => $this->request->getPost('childCategory') ?? null,
                'brandId'                     => $this->request->getPost('brandId') ?? null,
                'sellingPrice'                => $this->request->getPost('sellingPrice') ?? 0.00,
                'buyingPrice'                 => $this->request->getPost('buyingPrice') ?? 0.00,
                'gst'                         => $this->request->getPost('gst') ?? 0.00,
                'shortDescription'            => $this->request->getPost('shortDescription'),
                'longDescription'             => $this->request->getPost('longDescription'),
                'weight'                      => $this->request->getPost('weight') ?? 0.00,
                'length'                      => $this->request->getPost('length') ?? 0.00,
                'width'                       => $this->request->getPost('width') ?? 0.00,
                'height'                      => $this->request->getPost('height') ?? 0.00,
                'metaTitle'                   => $this->request->getPost('metaTitle'),
                'metaDescription'             => $this->request->getPost('metaDescription'),
                'metaKeywords'                => $this->request->getPost('metaKeywords'),
                'status'                      => $this->request->getPost('status'),
                'canPurchasable'              => $this->request->getPost('canPurchasable'),
                'refundable'                  => $this->request->getPost('refundable'),
                'cod'                         => $this->request->getPost('cod'),
                'trending'                    => $this->request->getPost('trending'),
                
               
            ];
        
            // Insert Product
            $productId = $crudModel->insertRecord('products', $productData);
        
            if ($productId) {
                // Insert into Product Stock table (openingStock)
                $stockData = [
                    'productId' => $productId,
                    'variantId' => null, // simple product
                    'openingStock' => $stock,
                    'purchaseQty' => 0,
                    'soldQty' => 0,
                    'returnedQty' => 0,
                    'reservedQty' => 0,
                    'minStockLevel' => 0,
                    'stockStatus'   => $this->request->getPost('stockStatus'),
                ];
                $crudModel->insertRecord('product_stocks', $stockData);
        
                // Handle Multiple Images
                $productImageFiles = $this->request->getFileMultiple('productImage');
        
                if (!empty($productImageFiles)) {
                    foreach ($productImageFiles as $imageFile) {
                        if ($imageFile->isValid() && !$imageFile->hasMoved()) {
                            $newImageName = $imageFile->getRandomName();
                            $imageFile->move('assets/admin/vijayaagni/products/', $newImageName);
        
                            // Insert into product_images table
                            $imageData = [
                                'productId' => $productId,
                                'name' => $newImageName,
                                'isPrimary' => 'No' // you can set main later if needed
                            ];
                            $crudModel->insertRecord('product_images', $imageData);
                        }
                    }
                }
        
                $session->setFlashdata('success', 'Product Inserted Successfully with Images and Stock');
                return redirect()->to(base_url('admin/product/add-product'));
            } else {
                $session->setFlashdata('error', 'Product Not Inserted');
                return redirect()->to(base_url('admin/product/add-product'));
            }
        }

    }
   
    /* ====================================
     Product List
    ===================================== */ 
    public function productList()
    {
        $data['pageTitle'] = 'Product List';
        $data['pageName']  = 'product-list';
        return view('Modules\Admin\Views\Pages\products\productList', $data);
    }

    
    
    /* ====================================
     Product List using Ajax
    ===================================== */
    public function getProductsList()
    {
        $db = \Config\Database::connect();
        $request = service('request');
    
        $draw = $request->getPost('draw');
        $start = $request->getPost('start');
        $length = $request->getPost('length');
        $searchArray = $request->getPost('search');
        $searchValue = $searchArray['value'] ?? '';

    
        // Total Records without Filtering
        $totalRecords = $db->table('products')->countAll();
    
        // Base Query with Join
        $builder = $db->table('products as p');
        $builder->select('p.id, p.name as productName, p.sellingPrice, p.status, p.trending, 
                          cat.name as categoryName, childCat.name as childCategoryName, brand.name as brandName');
        $builder->join('category as cat', 'cat.id = p.mainCategory', 'left');
        $builder->join('category as childCat', 'childCat.id = p.childCategory', 'left');
        $builder->join('brand', 'brand.id = p.brandId', 'left');
    
        // Search Filter
        if (!empty($searchValue)) {
            $builder->groupStart()
                ->like('p.name', $searchValue)
                ->orLike('cat.name', $searchValue)
                ->orLike('childCat.name', $searchValue)
                ->orLike('brand.name', $searchValue)
                ->groupEnd();
        }
    
        // Total Records with Filtering
        $totalFiltered = $builder->countAllResults(false);
    
        // Limit & Offset
        $builder->limit($length, $start);
    
        // Get Result
        $query = $builder->get();
        $data = [];
        $sn = $start + 1;
    
        foreach ($query->getResult() as $row) {
            // Action Buttons
            $action = '
                <a href="' . base_url('admin/product/view-product/' . $row->id) . '" class="btn text-info" title="View"><i class="fa fa-eye"></i></a>
                <a href="' . base_url('admin/product/edit-product/' . $row->id) . '" class="btn text-success" title="Edit"><i class="fa fa-pencil-square-o"></i></a>
                <a href="javascript:void(0);" onclick="confirmDelete(' . $row->id . ')" class="btn text-danger" title="Delete"><i class="fa fa-trash-o"></i></a>
            ';
    
            $data[] = [
                'sn'                => $sn++,
                'productName'       => esc($row->productName),
                'categoryName'      => esc($row->categoryName ?? 'N/A'),
                'childCategoryName' => esc($row->childCategoryName ?? 'N/A'),
                'brandName'         => esc($row->brandName ?? 'N/A'),
                'sellingPrice'      => number_format($row->sellingPrice, 2),
                'status'            => esc($row->status),
                'trending'          => esc($row->trending),
                'action'            => $action
            ];

        }
    
        // Response
        $response = [
            'draw' => intval($draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalFiltered,
            'data' => $data,
        ];
    
        return $this->response->setJSON($response);
    }
    
    /* ====================================
     Product Details
    ===================================== */
    public function viewProduct($id)
    {
        $db = \Config\Database::connect();
        
        // Product main data with Joins
        $builder = $db->table('products as p');
        $builder->select('p.*, 
                          cat.name as categoryName, 
                          childCat.name as childCategoryName, 
                          brand.name as brandName,
                          gst.gst as gstName');
        $builder->join('category as cat', 'cat.id = p.mainCategory', 'left');
        $builder->join('category as childCat', 'childCat.id = p.childCategory', 'left');
        $builder->join('brand', 'brand.id = p.brandId', 'left');
        $builder->join('gst', 'gst.id = p.gst', 'left');
        $builder->where('p.id', $id);
        $query = $builder->get();
        $product = $query->getRow();
    
        if (!$product) {
            return redirect()->to(base_url('admin/product/product-list'))->with('error', 'Product not found');
        }
    
        // Fetch product images
        $imagesBuilder = $db->table('product_images');
        $imagesBuilder->select('name');
        $imagesBuilder->where('productId', $id);
        $imagesQuery = $imagesBuilder->get();
        $images = $imagesQuery->getResult();
    
        // Pass data to view
        $data['pageTitle'] = 'Product Details';
        $data['pageName']  = 'product-list';
        $data['product']   = $product;
        $data['images']    = $images; // Pass images separately as array of objects
    
        return view('Modules\Admin\Views\Pages\products\productDetails', $data);
    }
    
    /* ====================================
     Edit Product
    ===================================== */
    public function editProduct($id)
    {
        $crudModel = new CrudModel();
        $db = \Config\Database::connect();
        
        // Fetch Product Data
        $builder = $db->table('products as p');
        $builder->select('p.*, cat.name as categoryName, childCat.name as childCategoryName, brand.name as brandName, gst.gst as gstName, product_stocks.currentStock as currentStock, product_stocks.stockStatus as stockStatus');
        $builder->join('category as cat', 'cat.id = p.mainCategory', 'left');
        $builder->join('category as childCat', 'childCat.id = p.childCategory', 'left');
        $builder->join('brand', 'brand.id = p.brandId', 'left');
        $builder->join('product_stocks', 'product_stocks.productId = p.id', 'left');
        $builder->join('gst', 'gst.id = p.gst', 'left');
        $builder->where('p.id', $id);
        $query = $builder->get();
        $product = $query->getRow();
    
        // Fetch Product Images
        $imgBuilder = $db->table('product_images');
        $imgBuilder->select('name');
        $imgBuilder->where('productId', $id);
        $images = $imgBuilder->get()->getResult();
    
        if (!$product) {
            return redirect()->to(base_url('admin/product/product-list'))->with('error', 'Product not found');
        }
        
        $data['pageTitle'] = 'Update Product Details';
        $data['pageName']  = 'product-list';
        $data['product'] = $product;
        $data['images'] = $images;
        $data['getAllBrand'] = $crudModel->getAllRecords('brand', ['status' => 'Active', 'isDeleted' => 'No'], ['id' => 'DESC']);
        $data['getAllGst'] = $crudModel->getAllRecords('gst', ['status' => 'Active', 'isDeleted' => 'No'], ['id' => 'ASC']);
        $data['getAllCategoryRecords'] = $crudModel->getAllRecords('category',['isDeleted' => 'No','parentId'  => 0,],['id' => 'DESC']);
        return view('Modules\Admin\Views\Pages\products\editProduct', $data);
    }
    
    /* ====================================
     Remove Product Image
    ===================================== */
    public function removeProductImage()
    {
        $imageName = $this->request->getPost('image');
        $productId = $this->request->getPost('productId');
    
        $db = \Config\Database::connect();
        $builder = $db->table('product_images');
        $builder->where(['productId' => $productId, 'name' => $imageName]);
        $builder->delete();
    
        $imagePath = FCPATH . 'uploads/products/' . $imageName;
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    
        return $this->response->setJSON(['status' => 'success']);
    }
    
    
    public function getChildCategory()
    {
        $parentId = $this->request->getPost('parentId');
        
        if ($parentId) {
            $db = \Config\Database::connect();
            $builder = $db->table('category');
            $builder->select('id, name');
            $builder->where(['parentId' => $parentId, 'isDeleted' => 'No']);
            $query = $builder->get();
            $result = $query->getResult();
            
            echo json_encode($result); // return as JSON to your AJAX
        } else {
            echo json_encode([]); // if no parentId is passed
        }
    }






    
    
    







    
}


?>