<?php

namespace Modules\Admin\Controllers;
use CodeIgniter\Controller;
use Modules\Admin\Models\CrudModel;

class Country extends Controller {
    
    /* ====================================
     Add Category
    ===================================== */
    public function addCountry()
    {
        
        $session = session();
    
        if ($this->request->is('get')) {
            $data['pageTitle'] = "Add Country";
            $data['pageName'] = "add-country";            
            return view('Modules\Admin\Views\Pages\country\addCountry', $data);
        }
    
        if ($this->request->is('post')) {
            // Validation Rules
            $validationRules = [
                'countryImage'       => 'required|max_length[150]|is_unique[category.name]',
                'CountryName'       => 'required|alpha_dash|max_length[255]|is_unique[category.slug]',

            ];
    
            // Custom Error Messages
            $validationMessages = [
                'name' => [
                    'required'   => 'Category name is required.',
                    'max_length'=> 'Category name must not exceed 150 characters.',
                    'is_unique' => 'This category name already exists.',
                ],
                'slug' => [
                    'required'   => 'Slug is required.',
                    'alpha_dash'=> 'Slug must only contain alphanumeric characters, underscores, or dashes.',
                    'max_length'=> 'Slug must not exceed 255 characters.',
                    'is_unique' => 'This slug is already in use.',
                ],
              
            ];
    
                if (!$this->validate($validationRules, $validationMessages)) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
    
            // Handle file upload
            $categoryImageFile = $this->request->getFile('image');
            $categoryImageName = '';
    
            if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                // Validate file size (max 1MB) and dimensions (512x512)
                $fileSize = $categoryImageFile->getSize(); // in bytes
                $fileSizeMB = $fileSize / 1024 / 1024; // convert to MB
    
                $imageInfo = getimagesize($categoryImageFile->getTempName());
                $width = $imageInfo[0];
                $height = $imageInfo[1];
    
                if ($fileSizeMB > 1) { // max 1MB
                    return redirect()->back()->withInput()->with('error', 'Image size must not exceed 1MB.');
                }
    
                if ($width > 512 || $height > 512) {
                    return redirect()->back()->withInput()->with('error', 'Image dimensions must not exceed 512x512 pixels.');
                }
    
                // Move the uploaded file to destination
                $categoryImageName = $categoryImageFile->getRandomName();
                $categoryImageFile->move('assets/admin/vijayaagni/category/', $categoryImageName);
            }
    
            // Prepare data for insert
            $categoryData = [
                'name'        => $this->request->getPost('name'),
                'slug'        => $this->request->getPost('slug'),
                'image'       => $categoryImageName,
                'status'      => $this->request->getPost('status'),
                'isTrending'  => $this->request->getPost('isTrending'),
                'parentId'    => 0, // Since this is primary menu
            ];
            
            $crudModel = new CrudModel();
            $lastID = $crudModel->insertRecord('category', $categoryData);
    
            if ($lastID) {
                $session->setFlashdata('success', 'Category Inserted Successfully');
                return redirect()->to(base_url('category/add-category'));
            } else {
                $session->setFlashdata('error', 'Category Not Inserted');
                return redirect()->to(base_url('category/add-category'));
            }
        }
    }


    /* ====================================
       Primary (Main) Category List
    ===================================== */
    public function countryList() {
        $data['pageTitle'] = 'Primary Category List';
        $data['pageName']  = 'category-list';
    
        $crudModel = new CrudModel();
        $data['getAllCategoryRecords'] = $crudModel->getAllRecords(
            'category', 
            [
                'isDeleted' => 'No',
                'parentId'  => 0,
            ],  
            ['id' => 'DESC'] // Order By
        );
    
        return view('Modules\Admin\Views\Pages\country\countryList', $data);
    }

    
    
    /* ====================================
     Update Category
    ===================================== */
    public function updatePrimaryMenu($categoryID)
    {
        $crudModel = new CrudModel();
        $session = session();
    
        if ($this->request->is('get')) {
            $data['pageTitle'] = "Edit Category";
            $data['pageName'] = "category-list"; 
            $data['getSingleCategoryRecord'] = $crudModel->getSingleRecord('category', ['id' => $categoryID]);
            return view('Modules\Admin\Views\Pages\category\editCategory', $data);
        }
    
        if ($this->request->is('post')) {
            // Validation Rules
            $validationRules = [
                'name'       => 'required|max_length[150]',
                'slug'       => 'required|alpha_dash|max_length[255]',
                'status'     => 'required|max_length[6]',
                'isTrending' => 'required|max_length[6]',
            ];
    
            $validationMessages = [
                'name' => [
                    'required'   => 'Category name is required.',
                    'max_length'=> 'Category name must not exceed 150 characters.',
                ],
                'slug' => [
                    'required'   => 'Slug is required.',
                    'alpha_dash'=> 'Slug must only contain alphanumeric characters, underscores, or dashes.',
                    'max_length'=> 'Slug must not exceed 255 characters.',
                ],
                'status' => [
                    'required'   => 'Category status is required.',
                    'max_length'=> 'Category status must not exceed 6 characters.',
                ],
                'isTrending' => [
                    'required'   => 'Category trending is required.',
                    'max_length'=> 'Category trending must not exceed 6 characters.',
                ],
            ];
    
            if (!$this->validate($validationRules, $validationMessages)) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
    
            // Handle file upload
            $categoryImageFile = $this->request->getFile('image');
            $categoryImageName = '';
    
            if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                $fileSize = $categoryImageFile->getSize(); 
                $fileSizeMB = $fileSize / 1024 / 1024;
    
                $imageInfo = getimagesize($categoryImageFile->getTempName());
                $width = $imageInfo[0];
                $height = $imageInfo[1];
    
                if ($fileSizeMB > 1) {
                    return redirect()->back()->withInput()->with('error', 'Image size must not exceed 1MB.');
                }
    
                if ($width > 512 || $height > 512) {
                    return redirect()->back()->withInput()->with('error', 'Image dimensions must not exceed 512x512 pixels.');
                }
    
                $categoryImageName = $categoryImageFile->getRandomName();
                $categoryImageFile->move('assets/admin/vijayaagni/category/', $categoryImageName);
            } else {
                // Image not uploaded, keep old image
                $existingData = $crudModel->getSingleRecord('category', ['id' => $categoryID]);
                $categoryImageName = $existingData->image ?? '';
            }
    
            $categoryData = [
                'name'        => $this->request->getPost('name'),
                'slug'        => $this->request->getPost('slug'),
                'image'       => $categoryImageName,
                'status'      => $this->request->getPost('status'),
                'isTrending'  => $this->request->getPost('isTrending'),
                'parentId'    => 0,
            ];
    
            $isUpdated = $crudModel->updateRecord('category', ['id' => $categoryID], $categoryData);
    
            if ($isUpdated) {
                $session->setFlashdata('success', 'Category Updated Successfully');
                return redirect()->to(base_url('admin/category/category-list'));
            } else {
                $session->setFlashdata('error', 'Category Not Updated');
            }
    
            return redirect()->to(base_url('admin/category/edit-category/' . $categoryID));
        }
    }

    /* ====================================
     Delete Category
    ===================================== */
    public function deleteCategory($primaryMenuID)
    {
        $session = session();
        $crudModel = new CrudModel();
    
        if ($this->request->is('get')) {
    
            // Check if the category exists and is not already deleted
            $getCategoryRecord = $crudModel->getSingleRecord('category', ['id' => $primaryMenuID, 'isDeleted' => 'No']);
    
            if (!$getCategoryRecord) {
                $session->setFlashdata('error', 'The category does not exist');
                return redirect()->to(base_url('admin/category/category-list'));
            }
    
            // Data to "soft delete" the record
            $categoryDetail = [
                'status'     => 'Block',
                'updatedAt'  => date('Y-m-d H:i:s'),
                'isDeleted'  => 'Yes'
            ];
    
            // Perform update (soft delete)
            $deleteCategory = $crudModel->updateRecord('category', ['id' => $primaryMenuID], $categoryDetail);
    
            if ($deleteCategory) {
                $session->setFlashdata('success', 'Category Deleted Successfully');
            } else {
                $session->setFlashdata('error', 'Category Not Deleted');
            }
    
            return redirect()->to(base_url('admin/category/category-list'));
        }
    }
    
    /* ====================================
     Add Child Category
    ===================================== */
    public function addChildCategory($parent_id)
    {
        $session = session();
        $crudModel = new CrudModel();
    
        // Get parent category object
        $parentCategory = $crudModel->getSingleRecord('category', ['id' => $parent_id, 'isDeleted' => 'No']);
    
        if (!$parentCategory) {
            $session->setFlashdata('error', 'Parent category not found.');
            return redirect()->to(base_url('admin/category/category-list'));
        }
    
        $pageTitle = 'Add Child Category for: ' . $parentCategory->name;
        $pageName  = 'category-list';
    
        if ($this->request->is('post')) {
    
            // Basic rules (without image mandatory)
            $rules = [
                'name'       => 'required|min_length[1]|max_length[255]',
                'slug'       => 'required|min_length[1]|max_length[255]',
                'status'     => 'required|in_list[Active,Block]',
                'isTrending' => 'required|in_list[Yes,No]',
            ];
    
            // Validate input except image
            if (!$this->validate($rules)) {
                return view('Modules\Admin\Views\Pages\category\addChildCategory', [
                    'validation'      => $this->validator,
                    'parentCategory'  => $parentCategory,
                    'childCategories' => $crudModel->getAllRecords('category', ['parentId' => $parent_id, 'isDeleted' => 'No']),
                    'pageTitle'       => $pageTitle,
                    'pageName'        => $pageName
                ]);
            }
    
            // Handle file upload (if file uploaded)
            $categoryImageFile = $this->request->getFile('image');
            $categoryImageName = '';
    
            if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                $fileSize = $categoryImageFile->getSize(); // in bytes
                $fileSizeMB = $fileSize / 1024 / 1024; // Convert to MB
    
                $imageInfo = getimagesize($categoryImageFile->getTempName());
                $width = $imageInfo[0];
                $height = $imageInfo[1];
    
                if ($fileSizeMB > 1) {
                    return redirect()->back()->withInput()->with('error', 'Image size must not exceed 1MB.');
                }
    
                if ($width > 512 || $height > 512) {
                    return redirect()->back()->withInput()->with('error', 'Image dimensions must not exceed 512x512 pixels.');
                }
    
                $categoryImageName = $categoryImageFile->getRandomName();
                $categoryImageFile->move('assets/admin/vijayaagni/category/', $categoryImageName);
            }
    
            $insertData = [
                'parentId'   => $parent_id,
                'name'       => $this->request->getPost('name'),
                'slug'       => $this->request->getPost('slug'),
                'image'      => $categoryImageName,
                'status'     => $this->request->getPost('status'),
                'isDeleted'  => 'No',
                'isTrending' => $this->request->getPost('isTrending'),
                'createdAt'  => date('Y-m-d H:i:s')
            ];
    
            $insert = $crudModel->insertRecord('category', $insertData);
    
            if ($insert) {
                $session->setFlashdata('success', 'Child Category Added Successfully');
            } else {
                $session->setFlashdata('error', 'Failed to add child category');
            }
    
            return redirect()->to(base_url('admin/category/add-child-category/' . $parent_id));
        }
    
        // GET Method
        $childCategories = $crudModel->getAllRecords('category', ['parentId' => $parent_id, 'isDeleted' => 'No']);
    
        return view('Modules\Admin\Views\Pages\category\addChildCategory', [
            'parentCategory'  => $parentCategory,
            'childCategories' => $childCategories,
            'pageTitle'       => $pageTitle,
            'pageName'        => $pageName
        ]);
    }
    
    
    /* ====================================
    Update Child Category
    ===================================== */
    public function updateChildCategory($id)
    {
        $session = session();
        $crudModel = new CrudModel();
    
        // Get child category by ID
        $childCategory = $crudModel->getSingleRecord('category', ['id' => $id, 'isDeleted' => 'No']);
    
        if (!$childCategory) {
            $session->setFlashdata('error', 'Child category not found.');
            return redirect()->to(base_url('admin/category/category-list'));
        }
    
        $pageTitle = 'Update Child Category: ' . $childCategory->name;
        $pageName  = 'category-list';
    
        if ($this->request->is('post')) {
    
            // Validation rules (image not required)
            $rules = [
                'name'       => 'required|min_length[1]|max_length[255]',
                'slug'       => 'required|min_length[1]|max_length[255]',
                'status'     => 'required|in_list[Active,Block]',
                'isTrending' => 'required|in_list[Yes,No]'
            ];
    
            if (!$this->validate($rules)) {
                return view('Modules\Admin\Views\Pages\category\updateChildCategory', [
                    'validation'     => $this->validator,
                    'childCategory'  => $childCategory,
                    'pageTitle'      => $pageTitle,
                    'pageName'       => $pageName
                ]);
            }
    
            // File Upload Logic (Only if new image provided)
            $categoryImageFile = $this->request->getFile('image');
            $categoryImageName = $childCategory->image; // keep old image by default
    
            if ($categoryImageFile && $categoryImageFile->isValid() && !$categoryImageFile->hasMoved()) {
                $fileSize = $categoryImageFile->getSize();
                $fileSizeMB = $fileSize / 1024 / 1024;
    
                $imageInfo = getimagesize($categoryImageFile->getTempName());
                $width = $imageInfo[0];
                $height = $imageInfo[1];
    
                if ($fileSizeMB > 1) {
                    return redirect()->back()->withInput()->with('error', 'Image size must not exceed 1MB.');
                }
    
                if ($width > 512 || $height > 512) {
                    return redirect()->back()->withInput()->with('error', 'Image dimensions must not exceed 512x512 pixels.');
                }
    
                $categoryImageName = $categoryImageFile->getRandomName();
                $categoryImageFile->move('assets/admin/vijayaagni/category/', $categoryImageName);
    
                // Remove old image if exists
                if (!empty($childCategory->image) && file_exists('assets/admin/vijayaagni/category/' . $childCategory->image)) {
                    unlink('assets/admin/vijayaagni/category/' . $childCategory->image);
                }
            }
    
            $updateData = [
                'name'       => $this->request->getPost('name'),
                'slug'       => $this->request->getPost('slug'),
                'image'      => $categoryImageName,
                'status'     => $this->request->getPost('status'),
                'isTrending' => $this->request->getPost('isTrending'),
                'updatedAt'  => date('Y-m-d H:i:s')
            ];
    
            $update = $crudModel->updateRecord('category', ['id' => $id], $updateData);
    
            if ($update) {
                $session->setFlashdata('success', 'Child Category Updated Successfully');
            } else {
                $session->setFlashdata('error', 'Failed to update child category');
            }
    
            return redirect()->to(base_url('admin/category/update-child-category/' . $id));
        }
    
        return view('Modules\Admin\Views\Pages\category\updateChildCategory', [
            'childCategory' => $childCategory,
            'pageTitle'     => $pageTitle,
            'pageName'      => $pageName
        ]);
    }
    
    
    /* ====================================
     Delete Child Category (Soft Delete)
    ==================================== */
    public function deleteChildCategory($childCategoryID)
    {
        $session = session();
        $crudModel = new CrudModel();
    
        if ($this->request->is('get')) {
    
            // Check if the child category exists and is not already deleted
            $getChildCategoryRecord = $crudModel->getSingleRecord('category', ['id' => $childCategoryID, 'isDeleted' => 'No']);
    
            if (!$getChildCategoryRecord) {
                $session->setFlashdata('error', 'The child category does not exist');
                return redirect()->to(base_url('admin/category/category-list'));
            }
    
            // Data to "soft delete" the record
            $childCategoryDetail = [
                'status'     => 'Block',
                'updatedAt'  => date('Y-m-d H:i:s'),
                'isDeleted'  => 'Yes'
            ];
    
            // Perform update (soft delete)
            $deleteChildCategory = $crudModel->updateRecord('category', ['id' => $childCategoryID], $childCategoryDetail);
    
            if ($deleteChildCategory) {
                $session->setFlashdata('success', 'Child Category Deleted Successfully');
            } else {
                $session->setFlashdata('error', 'Child Category Not Deleted');
            }
    
            return redirect()->to(base_url('admin/category/category-list'));
        }
    }








    
}


?>