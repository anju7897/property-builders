<?php

namespace Modules\Admin\Controllers;
use CodeIgniter\Controller;

    class Setting extends Controller
    {
        
        /* ======================
         Setting
        ========================== */
        public function systemSetting()
        {
            $session = session();
            if (!$session->get('logged_in')) {
                return redirect()->to(base_url('admin/login'));
            }
        
            $db = \Config\Database::connect();
            helper(['form']);
            if ($this->request->is('GET')) {
                $data['pageTitle'] = "Setting | Profile | Admin";
                $data['pageName'] = "system-setting-admin";
                $builder = $db->table('setting');
                $builder->select('*');
                $builder->where('id', '1');
                $data['getProfileRecord'] = $builder->get()->getRow();          
                return view('Modules\Admin\Views\Pages\setting\profile', $data);
            }
            
            if ($this->request->is('POST')) { 
                
                $rules = [
                    'name'           => 'permit_empty|max_length[45]',
                    'emailId'        => 'permit_empty|valid_email|max_length[100]',
                    'phoneNo'        => 'permit_empty|exact_length[10]',
                    'address'        => 'permit_empty|max_length[200]',
                    'gender'         => 'permit_empty|max_length[10]',
                    'dob'            => 'permit_empty|valid_date',
                    'gst'            => 'permit_empty|max_length[15]',
                    'country'        => 'permit_empty|max_length[50]',
                    'city'           => 'permit_empty|max_length[50]',
                    'state'          => 'permit_empty|max_length[50]',
                    'pinCode'        => 'permit_empty|max_length[10]',
                    'bankName'       => 'permit_empty|max_length[100]',
                    'accountHolder'  => 'permit_empty|max_length[100]',
                    'accountNumber'  => 'permit_empty|max_length[20]',
                    'ifscCode'       => 'permit_empty|max_length[11]',
                ];
                
                if (!$this->validate($rules)) {
                    return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
                }
    
                $profileData = [
                    'name'           => $this->request->getPost('name'),
                    'emailId'        => $this->request->getPost('emailId'),
                    'phoneNo'        => $this->request->getPost('phoneNo'),
                    'companyName'    => $this->request->getPost('companyName'),
                    'address'        => $this->request->getPost('address'),
                    'gender'         => $this->request->getPost('gender'),
                    'dob'            => $this->request->getPost('dob'), 
                    'gst'            => $this->request->getPost('gst'),
                    'country'        => $this->request->getPost('country'),
                    'state'          => $this->request->getPost('state'),
                    'city'           => $this->request->getPost('city'),
                    'pinCode'        => $this->request->getPost('pinCode'),
                    'bankName'       => $this->request->getPost('bankName'),
                    'accountHolder'  => $this->request->getPost('accountHolder'),
                    'accountNumber'  => $this->request->getPost('accountNumber'),
                    'ifscCode'       => $this->request->getPost('ifscCode'),
                   
                ];
    
                $request = service('request');
               
                // Handle logo upload
                $logoFile = $request->getFile('logo');
                if ($logoFile && $logoFile->isValid() && !$logoFile->hasMoved()) {
                    $logoName = $logoFile->getRandomName();
                    $logoFile->move('assets/admin/vijayaagni/logo/', $logoName);
                    $profileData['logo'] = $logoName;
                }
    
                // Handle fav_icon upload
                $faviconFile = $request->getFile('favIcon');
                if ($faviconFile && $faviconFile->isValid() && !$faviconFile->hasMoved()) {
                    $faviconName = $faviconFile->getRandomName();
                    $faviconFile->move('assets/admin/vijayaagni/logo/', $faviconName);
                    $profileData['favIcon'] = $faviconName;
                }
    
                // Handle qrCode upload
                $qrCodeFile = $request->getFile('qrCode');
                if($qrCodeFile && $qrCodeFile->isValid() && !$qrCodeFile->hasMoved()) {
                    $qrCodeName = $qrCodeFile->getRandomName();
                    $qrCodeFile->move('assets/admin/vijayaagni/logo/', $qrCodeName);
                    $profileData['qrCode'] = $qrCodeName;
                }
    
                $builder = $db->table('setting');
                $builder->where('id', '1');
                $builder->where('status', 'Active');
                $updateRecord = $builder->update($profileData);
    
                $session = session();
                if ($updateRecord) {
                    $session->setFlashdata('success', 'Record updated successfully.');
                    return redirect()->to(base_url('admin/profile'));
                } else {
                    $session->setFlashdata('error', 'Failed t   o update record.');
                    return redirect()->to(base_url('admin/profile'));
                }
            }
        }

        
        
    }


?>





