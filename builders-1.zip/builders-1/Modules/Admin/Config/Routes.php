<?php

$routes->group('admin/', ['namespace' => 'Modules\Admin\Controllers'], function($routes) {
    
    // login
    $routes->get('login',                                   'AdminLogin::adminLogin');
    $routes->post('login',                                  'AdminLogin::adminLogin');

    // Dashboard
    $routes->get('dashboard',                               'Dashboard::dashboard');

    // Logout - 
    $routes->get('logout',                                  'AdminLogin::logout', ['filter' => 'authCheck']);

    $routes->get('profile',                                 'Setting::systemSetting', ['filter' => 'authCheck']);
    $routes->post('profile',                                'Setting::systemSetting', ['filter' => 'authCheck']);
    

    // Banner

    $routes->get('banner/add-banner',                       'Banner::addBanner', ['filter' => 'authCheck']);
    $routes->post('banner/add-banner',                      'Banner::addBanner', ['filter' => 'authCheck']);
    $routes->get('banner/list-banner',                      'Banner::listBanner', ['filter' => 'authCheck']);
    $routes->get('banner/edit-banner/(:num)',               'Banner::editBanner/$1', ['filter' => 'authCheck']);
    $routes->post('banner/edit-banner/(:num)',              'Banner::editBanner/$1', ['filter' => 'authCheck']);


    $routes->get('banner/delete-banner/(:num)',             'Banner::deleteBanner/$1', ['filter' => 'authCheck']);


// Country
    $routes->get('country/add-country',                   'Country::addCountry', ['filter' => 'authCheck']);
    $routes->post('country/add-country',                  'Country::addCountry', ['filter' => 'authCheck']);
    $routes->get('country/country-list',                  'Country::countryList', ['filter' => 'authCheck']);

















    // Category - Blog
    $routes->get('blog/add-blog-category',                  'Blog::addCategory', ['filter' => 'authCheck']);
    $routes->post('blog/add-blog-category',                 'Blog::addCategory', ['filter' => 'authCheck']);
    $routes->get('blog/blog-category-list',                 'Blog::blogCategoryList', ['filter' => 'authCheck']);
    $routes->get('blog/edit-blog-category/(:num)',          'Blog::editBlogCategory/$1', ['filter' => 'authCheck']);
    $routes->post('blog/edit-blog-category/(:num)',         'Blog::editBlogCategory/$1', ['filter' => 'authCheck']);
    $routes->get('blog/delete-blog-category/(:num)',        'Blog::deletBlogCategory/$1', ['filter' => 'authCheck']);
    
    // Tags - Blog
    $routes->get('blog/add-blog-tags',                      'Blog::addTags', ['filter' => 'authCheck']);
    $routes->post('blog/add-blog-tags',                     'Blog::addTags', ['filter' => 'authCheck']);
    $routes->get('blog/blog-tags-list',                     'Blog::blogTagsList', ['filter' => 'authCheck']);
    $routes->get('blog/edit-blog-tags/(:num)',              'Blog::editBlogTags/$1', ['filter' => 'authCheck']);
    $routes->post('blog/edit-blog-tags/(:num)',             'Blog::editBlogTags/$1', ['filter' => 'authCheck']);
    $routes->get('blog/delete-blog-tags/(:num)',            'Blog::deletBlogTags/$1', ['filter' => 'authCheck']);
    
    // Post - Blog
    $routes->get('blog/add-blog-post',                      'Blog::addPost', ['filter' => 'authCheck']);
    $routes->post('blog/add-blog-post',                     'Blog::addPost', ['filter' => 'authCheck']);
    $routes->get('blog/post-list',                          'Blog::postList', ['filter' => 'authCheck']);
    $routes->get('blog/edit-post/(:num)',                   'Blog::editPost/$1', ['filter' => 'authCheck']);
    $routes->post('blog/edit-post/(:num)',                  'Blog::editPost/$1', ['filter' => 'authCheck']);
    
    
    $routes->get('category/update-category/(:num)',         'Category::updatePrimaryMenu/$1', ['filter' => 'authCheck']);
    $routes->post('category/update-category/(:num)',        'Category::updatePrimaryMenu/$1', ['filter' => 'authCheck']);
    $routes->get('category/delete-category/(:num)',         'Category::deleteCategory/$1', ['filter' => 'authCheck']);
    $routes->get('category/add-child-category/(:num)',      'Category::addChildCategory/$1', ['filter' => 'authCheck']);
    $routes->post('category/add-child-category/(:num)',     'Category::addChildCategory/$1', ['filter' => 'authCheck']);
    $routes->get('category/update-child-category/(:num)',   'Category::updateChildCategory/$1', ['filter' => 'authCheck']);
    $routes->post('category/update-child-category/(:num)',  'Category::updateChildCategory/$1', ['filter' => 'authCheck']);
    $routes->get('category/delete-child-category/(:num)',   'Category::deleteChildCategory/$1', ['filter' => 'authCheck']);
    
    
    // Product
    $routes->get('product/add-product',                     'Product::addProduct', ['filter' => 'authCheck']);
    $routes->post('product/add-product',                    'Product::addProduct', ['filter' => 'authCheck']);
    $routes->post('product/get-child-category',             'Product::getChildCategoriesUsingAjax', ['filter' => 'authCheck']);
    $routes->get('product/product-list',                    'Product::productList', ['filter' => 'authCheck']);
    $routes->post('product/get-product-list',               'Product::getProductsList', ['filter' => 'authCheck']);
    $routes->get('product/view-product/(:num)',             'Product::viewProduct/$1', ['filter' => 'authCheck']);
    $routes->get('product/edit-product/(:num)',             'Product::editProduct/$1', ['filter' => 'authCheck']);
    $routes->post('product/child-category',                 'Product::getChildCategory', ['filter' => 'authCheck']);
   
    
    



    
});

?>


