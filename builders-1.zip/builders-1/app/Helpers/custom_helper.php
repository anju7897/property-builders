<?php

if (!function_exists('generateSKU')) {
    function generateSKU($prefix = 'SKU', $length = 5) {
        $randomNumber = mt_rand(pow(10, $length-1), pow(10, $length)-1);
        return strtoupper($prefix) . '-' . $randomNumber;
    }
}


?>