<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');

$routes->setDefaultNamespace('Modules\Frontend\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');



// Load Frontend Routes
if (file_exists(ROOTPATH . 'Modules/Frontend/Config/Routes.php')) {
    require ROOTPATH . 'Modules/Frontend/Config/Routes.php';
}

// Load Admin Routes
if (file_exists(ROOTPATH . 'Modules/Admin/Config/Routes.php')) {
    require ROOTPATH . 'Modules/Admin/Config/Routes.php';
}

