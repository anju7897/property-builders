<?php
namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthCheck implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (!$session->get('logged_in')) {
            // Agar URI admin hai, to admin/login pe redirect karo
            $uri = service('uri')->getSegment(1); // first part of the URL

            if ($uri === 'admin') {
                return redirect()->to(base_url('admin/login'));
            } else {
                return redirect()->to(base_url('super/login'));
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Nothing for after
    }
}
?>
