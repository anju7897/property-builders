<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Document</title>
</head>
<body>
<section class="py-2">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <h4 class="text-center mt-5">Registration Form</h4>

        <!-- Flash Message -->
        <?php if(session()->getFlashdata('success')): ?>
          <div class="alert alert-success"><?= session()->getFlashdata('success'); ?></div>
        <?php elseif(session()->getFlashdata('error')): ?>
          <div class="alert alert-danger"><?= session()->getFlashdata('error'); ?></div>
        <?php endif; ?>

        <form action="<?= base_url('form'); ?>" method="post">
          <div class="row">
            <div class="mb-3">
              <input type="text" placeholder="Enter Your Name" name="fullName" class="form-control">
            </div>
            <div class="mb-3">
              <input type="date" placeholder="Date of birthday" name="dob" class="form-control">
            </div>
            <div class="mb-3">
              <input type="email" placeholder="Enter Your Email Id" name="email" class="form-control">
            </div>
            <div class="mb-3">
              <select name="gender" class="form-control">
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div class="mb-3">
              <input type="password" placeholder="Create Password" name="password" class="form-control">
            </div>
            <div class="mb-3">
              <input type="password" placeholder="Confirm Password" name="cpassword" class="form-control">
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
</body>
</html>
